import SwiftUI
import PhotosUI

struct AppointmentFormView: View {
    @State private var name = ""
    @State private var age = ""
    @State private var complaint = ""
    @State private var selectedDate = Date()
    @State private var selectedDoctor = "Dr. Janani"
    @State private var selectedImage: PhotosPickerItem?
    @State private var profileImage: Image?

    @State private var showAlert = false
    @State private var alertMessage = ""

    let doctors = ["Dr. Janani", "Dr. Pavithara", "Dr. Arishya", "Dr. Muthu"]

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.5), Color.blue.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                // Your content here...


                ScrollView {
                    appointmentForm
                        .padding()
                        .background(Color.white.opacity(0.4))
                        .cornerRadius(16)
                        .shadow(radius: 4)
                        .padding(.horizontal)
                }
            }
            .navigationTitle("Appointment Form")
            .navigationBarTitleDisplayMode(.inline)
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Appointment Status"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    // MARK: - Form Section
    var appointmentForm: some View {
        VStack(spacing: 20) {
            patientTextFields
            datePickerSection
            imagePickerSection
            doctorPickerSection

            Button(action: submitAppointment) {
                Text("Confirm Appointment")
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(10)
            }
        }
    }

    // MARK: - Patient TextFields
    var patientTextFields: some View {
        Group {
            TextField("Patient Name", text: $name)
            TextField("Age", text: $age).keyboardType(.numberPad)
            TextField("Reason for Visit", text: $complaint)
        }
        .padding()
        .background(Color(hex: "#E6E6FA"))
        .cornerRadius(10)
    }

    // MARK: - Date Picker
    var datePickerSection: some View {
        DatePicker("Select Date & Time", selection: $selectedDate, in: Date()..., displayedComponents: [.date, .hourAndMinute])
            .padding()
            .background(Color(hex: "#E6E6FA"))
            .cornerRadius(10)
    }

    // MARK: - Doctor Picker
    var doctorPickerSection: some View {
        Picker("Select Doctor", selection: $selectedDoctor) {
            ForEach(doctors, id: \.self) { doctor in
                Text(doctor)
            }
        }
        .padding()
        .background(Color(hex: "#E6E6FA"))
        .cornerRadius(10)
    }

    // MARK: - Image Picker
    var imagePickerSection: some View {
        VStack {
            if let profileImage = profileImage {
                profileImage
                    .resizable()
                    .scaledToFit()
                    .frame(height: 180)
                    .cornerRadius(10)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.purple, lineWidth: 2))
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .strokeBorder(style: StrokeStyle(lineWidth: 2, dash: [5]))
                        .frame(height: 180)
                        .foregroundColor(.gray.opacity(0.5))
                        .background(Color(hex: "#E6E6FA"))
                    VStack {
                        Image(systemName: "photo.on.rectangle")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 40, height: 40)
                            .foregroundColor(.gray)
                        Text("Tap to select an image")
                            .foregroundColor(.gray)
                            .font(.caption)
                    }
                }
            }

            PhotosPicker("Select Image", selection: $selectedImage, matching: .images)
                .onChange(of: selectedImage) { newItem in
                    loadImage(from: newItem)
                }
        }
    }

    // MARK: - Load Image
    func loadImage(from item: PhotosPickerItem?) {
        Task {
            if let data = try? await item?.loadTransferable(type: Data.self),
               let uiImage = UIImage(data: data) {
                profileImage = Image(uiImage: uiImage)
            }
        }
    }

    // MARK: - Submit Logic
    func submitAppointment() {
        guard let url = URL(string: "http://http://14.139.187.229:8081/mca/integris/patient_appoinment.php") else {
            alertMessage = "Invalid API URL"
            showAlert = true
            return
        }

        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let formattedDate = formatter.string(from: selectedDate)

        let params: [String: String] = [
            "name": name,
            "age": age,
            "complaint": complaint,
            "selectedDate": formattedDate,
            "selectedDoctor": selectedDoctor
        ]

        let bodyString = params.map {
            "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
        }.joined(separator: "&")

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = bodyString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    alertMessage = "Network error: \(error.localizedDescription)"
                } else if let data = data,
                          let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                          let message = json["message"] as? String {
                    alertMessage = message
                } else {
                    alertMessage = "Invalid server response"
                }
                showAlert = true
            }
        }.resume()
    }
}



// MARK: - Preview
#Preview {
    AppointmentFormView()
}
