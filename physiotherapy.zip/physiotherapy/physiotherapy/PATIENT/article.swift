import SwiftUI

struct PhysioDoctorIntroView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Title
                Text("Healing Through Movement")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
                    .padding(.top)

                // Subtitle
                Text("An Introduction to a Specialist Physiotherapy Doctor")
                    .font(.title2)
                    .foregroundColor(.gray)

                Divider()

                // Section 1 - Introduction
                Text("Introduction to Physiotherapy")
                    .font(.title3)
                    .fontWeight(.semibold)

                Text("Physiotherapy, also known as physical therapy, is a healthcare profession focused on restoring and maintaining physical function, mobility, and well-being. Whether it's recovering from a sports injury, managing arthritis, or regaining movement after a stroke, physiotherapy offers a non-invasive, drug-free path to recovery.")

                // Section 2 - Doctor Intro
                Text("Meet Dr. Raghavendra – A Specialist in Motion and Rehabilitation")
                    .font(.title3)
                    .fontWeight(.semibold)

                Text("Dr. Raghavendra brings years of clinical experience and a deep understanding of human movement to their role as a physiotherapist. Specializing in musculoskeletal and neurorehabilitation, Dr. Raghavendra has helped countless patients regain strength, mobility, and independence through personalized treatment plans.")

                // Section 3 - Expertise
                Text("Specialization and Expertise")
                    .font(.title3)
                    .fontWeight(.semibold)

                VStack(alignment: .leading, spacing: 10) {
                    Text("• Orthopedic Rehabilitation")
                    Text("• Neurological Physiotherapy")
                    Text("• Pediatric & Geriatric Care")
                    Text("• Chronic Pain Management")
                }

                // Section 4 - Conclusion
                Text("Making a Difference, One Patient at a Time")
                    .font(.title3)
                    .fontWeight(.semibold)

                Text("What truly sets Dr. Raghavendra apart is their dedication to not just treating the condition but empowering the patient. By educating patients about their bodies and promoting active participation in their recovery, they ensure sustainable results.")

                Text("In the hands of a committed physiotherapist like Dr. Raghavendra, healing becomes a journey of strength, resilience, and renewal. Their work as a specialist physio is more than just treating pain—it's about restoring hope, movement, and quality of life.")

                Spacer()
            }
            .padding()
        }
        .navigationTitle("About Doctor")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Preview
#Preview {
    NavigationView {
        PhysioDoctorIntroView()
    }
}

