import SwiftUI
import AVKit

struct RecommendationView: View {
    var recommendation: Recommendation

    @State private var isLiked = false
    @State private var isDisliked = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Video Player
                VideoPlayer(player: AVPlayer(url: URL(string: recommendation.videoURL)!))
                    .frame(height: 250)
                    .background(Color.black)

                // Title
                Text(recommendation.title)
                    .font(.title2)
                    .fontWeight(.semibold)
                    .padding(.horizontal)

                // Metadata (views + duration)
                HStack {
                    Text("\(recommendation.users) views")
                    Text("• \(recommendation.duration)")
                    Spacer()
                }
                .font(.subheadline)
                .foregroundColor(.gray)
                .padding(.horizontal)

                // Like/Dislike/Share
                HStack(spacing: 40) {
                    Button(action: {
                        isLiked.toggle()
                        if isLiked { isDisliked = false }
                    }) {
                        VStack {
                            Image(systemName: isLiked ? "hand.thumbsup.fill" : "hand.thumbsup")
                                .font(.title2)
                            Text("Like")
                                .font(.caption)
                        }
                    }

                    Button(action: {
                        isDisliked.toggle()
                        if isDisliked { isLiked = false }
                    }) {
                        VStack {
                            Image(systemName: isDisliked ? "hand.thumbsdown.fill" : "hand.thumbsdown")
                                .font(.title2)
                            Text("Dislike")
                                .font(.caption)
                        }
                    }

                    Button(action: {
                        // share functionality (not implemented)
                    }) {
                        VStack {
                            Image(systemName: "square.and.arrow.up")
                                .font(.title2)
                            Text("Share")
                                .font(.caption)
                        }
                    }

                    Spacer()
                }
                .foregroundColor(.primary)
                .padding(.horizontal)

                Divider().padding(.horizontal)

                // Category and Info
                VStack(alignment: .leading, spacing: 8) {
                    Text("Category: \(recommendation.category)")
                        .font(.subheadline)
                    Text("Duration: \(recommendation.duration)")
                        .font(.subheadline)
                }
                .padding(.horizontal)

                // Description
                VStack(alignment: .leading, spacing: 8) {
                    Text("Description")
                        .font(.headline)

                    Text("""
                    This video guides you through a session of "\(recommendation.title)" focused on \(recommendation.category). Follow along to improve flexibility, strength, and posture.
                    """)
                        .font(.body)
                        .foregroundColor(.secondary)
                }
                .padding(.horizontal)

                Spacer()
            }
            .padding(.top)
        }
        .navigationTitle("Watch")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Preview
#Preview {
    RecommendationVideoView(recommendation:
        Recommendation(
            imageName: "EXERCISE",
            duration: "15 Minutes",
            title: "Back Stretch",
            category: "Stretching",
            users: "500",
            videoURL: "https://www.w3schools.com/html/mov_bbb.mp4"
        )
    )
}
