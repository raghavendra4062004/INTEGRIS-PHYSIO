import SwiftUI
import MapKit

// MARK: - Clinic Model
struct ClinicModes2: Identifiable {
    let id = UUID()
    let name: String
    let city: String
    let distance: String
    let price: String
    let logoName: String
    let latitude: Double
    let longitude: Double
    let address: String
    let description: String
}

// MARK: - Sample Clinic Data
let Clinic2 = ClinicModes2(
    name: "Wellness Plus Therapy",
    city: "Chennai",
    distance: "9 km",
    price: "Rs 200.000 - 400.000",
    logoName: "clinic_logo_3",
    latitude: 13.0500,
    longitude: 80.2500,
    address: "No 42, 2nd Main Road, Anna Nagar, Chennai - 600040",
    description:
    """
    More than just treatment—Wellness Plus Therapy empowers you to live pain-free.
    Their integrated approach covers physical therapy, mobility training, and long-term health strategies.
    In-clinic or online, every session moves you closer to total wellness.
    """
)

// MARK: - Clinic Detail View
struct ClinicDetailView2: View {
    let clinic: ClinicModes2
    @State private var region: MKCoordinateRegion
    @State private var navigateToAppointment = false
    @Environment(\.presentationMode) var presentationMode

    init(clinic: ClinicModes2) {
        self.clinic = clinic
        _region = State(initialValue: MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: clinic.latitude, longitude: clinic.longitude),
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        ))
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {

            HStack {
                   
                    Spacer()
                    Text("Detail")
                        .font(.title2)
                        .bold()
                    Spacer()
                    Spacer().frame(width: 44)
                }

                // Clinic Image
                Image("CLINIC2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 110, height: 110)
                    .padding(.top, -10)

                // Clinic Name
                Text(clinic.name.uppercased())
                    .font(.title)
                    .fontWeight(.bold)

                // Address & Map Button
                Button(action: {
                    openInMaps(latitude: clinic.latitude, longitude: clinic.longitude)
                }) {
                    HStack(alignment: .top, spacing: 12) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(clinic.distance)
                                .font(.headline)
                                .foregroundColor(.blue)

                            Text(clinic.address)
                                .font(.subheadline)
                                .foregroundColor(.black)
                                .lineLimit(nil)
                        }
                        Spacer()
                        Image(systemName: "mappin.and.ellipse")
                            .foregroundColor(.blue)
                    }
                    .padding()
                    .background(Color.purple.opacity(0.2))
                    .cornerRadius(20)
                    .padding(.horizontal)
                }
                .buttonStyle(PlainButtonStyle())

                // Description
                ScrollView {
                    Text(clinic.description)
                        .font(.body)
                        .foregroundColor(.gray)
                        .padding(.horizontal)
                        .multilineTextAlignment(.leading)
                }

                Spacer()

                // Reserve Slot Button (navigate)
                Button(action: {
                    navigateToAppointment = true
                }) {
                    Text("Reserve Slot")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .cornerRadius(20)
                }
                .padding(.horizontal)
                .padding(.bottom, 30)

                // Hidden NavigationLink
                NavigationLink(destination: AppointmentFormView(), isActive: $navigateToAppointment) {
                    EmptyView()
                }
            }
            .background(Color(red: 0.93, green: 0.90, blue: 0.98))
            .edgesIgnoringSafeArea(.bottom)
        }
    }

    // Open Maps Function
    func openInMaps(latitude: Double, longitude: Double) {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let placemark = MKPlacemark(coordinate: coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = clinic.name
        mapItem.openInMaps(launchOptions: nil)
    }
}

// MARK: - Preview
struct ClinicDetailView2_Previews: PreviewProvider {
    static var previews: some View {
        ClinicDetailView2(clinic: Clinic2)
    }
}
