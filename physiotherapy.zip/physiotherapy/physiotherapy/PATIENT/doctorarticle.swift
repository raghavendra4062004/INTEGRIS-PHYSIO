import SwiftUI

struct DoctorArticleView2: View {
    @State private var articles: [ArticleModel] = []
    @State private var isLoading = true
    @State private var showError = false

    var body: some View {
        NavigationView {
            VStack {
                if isLoading {
                    ProgressView("Loading...")
                } else if showError {
                    Text("Failed to load articles.")
                        .foregroundColor(.red)
                } else {
                    List(articles, id: \.id) { article in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(article.title)
                                .font(.headline)
                            Text("By \(article.doctor_name)")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            Text(article.content)
                                .font(.body)

                            if let imagePath = article.image_path,
                               let imageUrl = URL(string: "http://localhost/physiotherapy/\(imagePath)") {
                                AsyncImage(url: imageUrl) { image in
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(height: 180)
                                        .clipped()
                                        .cornerRadius(10)
                                } placeholder: {
                                    ProgressView()
                                }
                            }
                        }
                        .padding(.vertical, 8)
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Articles")
            .onAppear {
                fetchArticles()
            }
        }
    }

    func fetchArticles() {
        guard let url = URL(string: "http://http://14.139.187.229:8081/mca/integris/get_article_details.php") else {
            print("Invalid URL")
            self.showError = true
            self.isLoading = false
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            DispatchQueue.main.async {
                self.isLoading = false

                guard let data = data, error == nil else {
                    print("Network error:", error?.localizedDescription ?? "Unknown error")
                    self.showError = true
                    return
                }

                do {
                    let response = try JSONDecoder().decode(APIResponse.self, from: data)
                    if response.success {
                        self.articles = response.data
                    } else {
                        self.showError = true
                    }
                } catch {
                    print("Decoding error:", error)
                    self.showError = true
                }
            }
        }.resume()
    }
}

// MARK: - Model

struct ArticleModel: Codable {
    let id: String
    let doctor_name: String
    let speciality: String
    let title: String
    let content: String
    let created_at: String
    let image_path: String?
}

struct APIResponse: Codable {
    let success: Bool
    let data: [ArticleModel]
}

// MARK: - Preview

#Preview {
    DoctorArticleView2()
}
