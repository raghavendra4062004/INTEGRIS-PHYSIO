import SwiftUI
import Foundation

// MARK: - Patient Model
class PatientModel: ObservableObject {
    @Published var name: String = ""
    @Published var age: String = ""
    @Published var dob: String = ""
    @Published var gender: String = ""
    @Published var phone: String = ""
    @Published var address: String = ""
}

// MARK: - Add Patient Details Page
struct AddPatientDetailsView: View {
    @StateObject var patient = PatientModel()
    @State private var navigateToHome = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    let genders = ["Male", "Female", "Other"]
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .topLeading) {
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.blue.opacity(0.6)]),
                    startPoint: .bottomLeading,
                    endPoint: .topTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Text("Patient Details")
                        .font(.largeTitle)
                        .foregroundColor(.purple)
                        .padding(.top)
                    
                    ScrollView {
                        Spacer()
                        
                        VStack(spacing: 20) {
                            TextField("Patient Name", text: $patient.name)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                            TextField("Age", text: $patient.age)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .keyboardType(.numberPad)
                            
                            TextField("Date of Birth", text: $patient.dob)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                            VStack(alignment: .leading, spacing: 7) {
                                Text("Gender")
                                    .fontWeight(.semibold)
                                    .foregroundColor(.purple)
                                
                                Picker("Gender", selection: $patient.gender) {
                                    ForEach(genders, id: \.self) { genderOption in
                                        Text(genderOption)
                                            .foregroundColor(.purple)
                                            .tag(genderOption)
                                    }
                                }
                                .pickerStyle(SegmentedPickerStyle())
                            }
                            
                            TextField("Phone Number", text: $patient.phone)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .keyboardType(.phonePad)
                            
                            TextField("Address", text: $patient.address)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                        .padding()
                        .background(Color.white.opacity(0.5))
                        .cornerRadius(12)
                        .padding()
                        
                        Spacer()
                        
                        Button(action: {
                            savePatientData()
                        }) {
                            Text("Save and Continue to Home")
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.purple)
                                .cornerRadius(10)
                        }
                        .padding()
                        .alert(isPresented: $showAlert) {
                            Alert(title: Text("Info"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                        }
                        
                        NavigationLink(destination: PATIENTHOME()
                            .navigationBarBackButtonHidden(true),
                                       isActive: $navigateToHome) {
                            EmptyView()
                        }
                    }
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
    
    // MARK: - API Call to PHP
    func savePatientData() {
        guard let url = URL(string: "http://http://14.139.187.229:8081/mca/integris/patientdetailnew.php") else {
            self.alertMessage = "Invalid server URL."
            self.showAlert = true
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let bodyData = "name=\(patient.name)&age=\(patient.age)&dob=\(patient.dob)&gender=\(patient.gender)&phone=\(patient.phone)&address=\(patient.address)"
        
        request.httpBody = bodyData.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.alertMessage = "Network error: \(error.localizedDescription)"
                    self.showAlert = true
                    return
                }
                
                guard let data = data else {
                    self.alertMessage = "No response from server."
                    self.showAlert = true
                    return
                }
                
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                       let status = json["status"] as? String,
                       let message = json["message"] as? String {
                        
                        if status == "success" {
                            self.alertMessage = message
                            self.navigateToHome = true
                        } else {
                            self.alertMessage = message
                        }
                        self.showAlert = true
                    } else {
                        self.alertMessage = "Invalid server response."
                        self.showAlert = true
                    }
                } catch {
                    self.alertMessage = "Failed to parse response."
                    self.showAlert = true
                }
            }
        }.resume()
    }
}

// MARK: - Preview
#Preview {
    AddPatientDetailsView()
}
