import SwiftUI

// MARK: - Model
struct Doctor: Identifiable {
    let id = UUID()
    let name: String
    let experience: String
    let price: String
    let rating: Double
    let imageName: String
}

// MARK: - Color Extension for Hex and Custom Colors
extension Color {
    init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.hasPrefix("#") ? String(hexSanitized.dropFirst()) : hexSanitized
        var rgb: UInt64 = 0
        Scanner(string: hexSanitized).scanHexInt64(&rgb)
        let r = Double((rgb >> 16) & 0xFF) / 255.0
        let g = Double((rgb >> 8) & 0xFF) / 255.0
        let b = Double(rgb & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b)
    }

}

// MARK: - Main Tab View
struct ConsultationMainView: View {
    @State private var selectedTab = 2

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }.tag(0)

            NavigationView {
                ConsultationView()
                    .navigationBarTitle("Consultation", displayMode: .inline)
            }
            .tabItem {
                Image(systemName: "stethoscope")
                Text("Consultation")
            }.tag(2)

            ClinicListView()
                .tabItem {
                    Image(systemName: "cross.case.fill")
                    Text("Clinic")
                }.tag(3)

            AppointmentFormView()
                .tabItem {
                    Image(systemName: "bubble.left.and.bubble.right.fill")
                    Text("Forum")
                }.tag(1)

            PatientInfoView()
                .tabItem {
                    Image(systemName: "person.crop.circle.fill")
                    Text("Profile")
                }.tag(4)
        }
        .toolbarBackground(Color.purple, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        .accentColor(.purple)
    }
}

// MARK: - Consultation View
struct ConsultationView: View {
    let doctors = [
        Doctor(name: "Dr. Janani", experience: "4 years", price: "Rs 1,500", rating: 4.9, imageName: "JANU"),
        Doctor(name: "Dr. Muthu", experience: "5 years", price: "Rs 1,800", rating: 4.8, imageName: "MUTHU"),
        Doctor(name: "Dr. Arishiya", experience: "3 years", price: "Rs 1,000", rating: 4.7, imageName: "ARISHYA"),
        Doctor(name: "Dr. Dhikshitha", experience: "2 years", price: "Rs 1,000", rating: 4.6, imageName: "ARISHYA")
    ]

    var body: some View {
        ZStack {
            // ✅ Gradient Background
            LinearGradient(
                gradient: Gradient(colors: [Color.darkLavender, Color.blue.opacity(0.4)]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("LivAe Doctors")
                        .font(.title3)
                        .bold()
                        .padding(.leading)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 15) {
                            ForEach(doctors) { doctor in
                                ZStack(alignment: .topTrailing) {
                                    Image(doctor.imageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: 80, height: 80)
                                        .clipShape(RoundedRectangle(cornerRadius: 20))

                                    Circle()
                                        .fill(Color.green)
                                        .frame(width: 12, height: 12)
                                        .offset(x: -5, y: 5)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }

                    Text("Menu")
                        .font(.title3)
                        .bold()
                        .padding(.leading)

                    VStack(spacing: 20) {
                        ForEach(doctors) { doctor in
                            DoctorCardView(doctor: doctor)
                        }
                    }
                    .padding(.bottom, 50)
                }
                .padding(.top)
            }
        }
    }
}

// MARK: - Doctor Card View
struct DoctorCardView: View {
    let doctor: Doctor

    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Image(doctor.imageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 80, height: 105)
                .clipShape(RoundedRectangle(cornerRadius: 20))

            VStack(alignment: .leading, spacing: 6) {
                Text(doctor.name)
                    .font(.headline)

                Text("Experience: \(doctor.experience)")
                    .font(.subheadline)
                    .foregroundColor(.gray)

                Text("Price: \(doctor.price)")
                    .font(.subheadline)
                    .foregroundColor(.gray)

                HStack(spacing: 4) {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                        .font(.subheadline)
                    Text(String(format: "%.1f", doctor.rating))
                        .foregroundColor(.black)
                        .font(.subheadline)
                }
            }

            Spacer()

            NavigationLink(destination: DoctorDetailView(doctor: doctor)) {
                Text("Consult")
                    .font(.caption)
                    .foregroundColor(.white)
                    .padding(.vertical, 6)
                    .padding(.horizontal, 12)
                    .background(Color.purple)
                    .cornerRadius(10)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 5)
        .padding(.horizontal)
    }
}

// MARK: - Doctor Detail View
struct DoctorDetailView: View {
    let doctor: Doctor
    @State private var showVideo = false
    @State private var isConsultNowTapped = false // ✅ Add this line here
    @Environment(\.dismiss) var dismiss


    var body: some View {
        ZStack {
            // ✅ Gradient Background
            LinearGradient(
                gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.5)]),
                startPoint: .topLeading,
                endPoint: .topTrailing
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 20) {
                    Image(doctor.imageName)
                        .resizable()
                        .frame(width: 150, height: 150)
                        .clipShape(Circle())
                        .shadow(radius: 10)
                        .padding(.top, 20)

                    Text(doctor.name)
                        .font(.title2)
                        .bold()

                    Text("Specialization: Physiotherapist")
                        .font(.subheadline)

                    Text("Experience: \(doctor.experience)")
                        .font(.subheadline)

                    Text("Consultation Fee: \(doctor.price)")
                        .font(.subheadline)

                    HStack {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                        Text(String(format: "%.1f", doctor.rating))
                    }

                    Divider().padding(.vertical)
                    
                    NavigationLink(destination: AppointmentFormView(),
                                   isActive: $isConsultNowTapped) {
                                          EmptyView()
                                      }
                                      .hidden()

                                      Button(action: {
                                          isConsultNowTapped = true
                                      }) {
                        Label("Consult Now", systemImage: "message.fill")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .padding(.horizontal)
                    }


                    VStack(alignment: .leading, spacing: 10) {
                        Text("Doctor's Advice")
                            .font(.headline)
                            .padding(.horizontal)

                        Text("""
                            • Stay hydrated
                            • Regular walk 30 mins/day
                            • Avoid junk food
                            • Monitor blood pressure weekly
                            """)
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .padding(.horizontal)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Exercise Video")
                            .font(.headline)
                            .padding(.horizontal)

                        Image("exercise_thumbnail")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(height: 200)
                            .cornerRadius(15)
                            .padding(.horizontal)

                        Button(action: {
                            showVideo = true
                        }) {
                            Text("Play Exercise Video")
                                .font(.caption)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        .padding(.horizontal)
                    }

                    Spacer()
                }
                .padding(.bottom, 40)
            }
            .navigationTitle("Doctor Details")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        dismiss()
                    }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                    }
                }
            }
            .sheet(isPresented: $showVideo) {
                ExerciseVideo1()
            }
        }
    }
}

// MARK: - Exercise Video View
struct ExerciseVideo1: View {
    var body: some View {
        ZStack {
            // ✅ Gradient Background
            LinearGradient(
                gradient: Gradient(colors: [Color.darkLavender, Color.blue.opacity(0.4)]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Exercise Video")
                    .font(.title)
                    .bold()
                    .padding()

                Image("thumbnail")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(15)
                    .padding()

                Text("This is a demonstration of physiotherapy exercises to improve flexibility and strength.")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    .padding()

                Spacer()
            }
            .padding()
        }
    }
}

// MARK: - Preview
#Preview {
    ConsultationMainView()
}
