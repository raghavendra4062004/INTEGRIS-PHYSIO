import SwiftUI
import AVKit

// MARK: - Safe Unique Model (renamed to avoid conflict)
struct DoctorVideoModel: Identifiable, Decodable {
    let id: String
    let title: String
    let description: String
    let filename: String
    let video_url: String
}

// MARK: - Response Wrapper
struct VideoResponse: Decodable {
    let status: String
    let videos: [DoctorVideoModel]
}

// MARK: - Video List Screen
struct VideoListView: View {
    @State private var videos: [DoctorVideoModel] = []
    @State private var isLoading = true
    @State private var showError = false

    var body: some View {
        NavigationView {
            Group {
                if isLoading {
                    ProgressView("Loading videos...")
                } else if showError {
                    Text("Failed to load videos.")
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                        .padding()
                } else {
                    List(videos) { video in
                        NavigationLink(destination: VideoPlayerView(videoURL: video.video_url)) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(video.title)
                                    .font(.headline)
                                Text(video.description)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .navigationTitle("Doctor Videos")
            .onAppear {
                fetchVideos()
            }
        }
    }

    // ✅ Fetch videos from your PHP backend
    func fetchVideos() {
        guard let url = URL(string: "http://your-ip-address/get_videos.php") else { return }

        URLSession.shared.dataTask(with: url) { data, _, error in
            DispatchQueue.main.async {
                isLoading = false
                if let data = data {
                    do {
                        let result = try JSONDecoder().decode(VideoResponse.self, from: data)
                        if result.status == "success" {
                            self.videos = result.videos
                        } else {
                            showError = true
                        }
                    } catch {
                        showError = true
                        print("JSON Decoding error:", error.localizedDescription)
                    }
                } else {
                    showError = true
                    print("Network error:", error?.localizedDescription ?? "Unknown error")
                }
            }
        }.resume()
    }
}

// MARK: - AVPlayer View
struct VideoPlayerView: View {
    let videoURL: String

    var body: some View {
        VStack {
            if let url = URL(string: videoURL) {
                VideoPlayer(player: AVPlayer(url: url))
                    .aspectRatio(16/9, contentMode: .fit)
                    .cornerRadius(12)
                    .padding()
            } else {
                Text("Invalid video URL")
                    .foregroundColor(.red)
            }
        }
        .navigationTitle("Play Video")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Preview
struct VideoListView_Previews: PreviewProvider {
    static var previews: some View {
        let mockVideo = DoctorVideoModel(
            id: "1",
            title: "Sample Stretch",
            description: "Demo video for stretching",
            filename: "sample.mp4",
            video_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
        )

        NavigationView {
            List([mockVideo]) { video in
                NavigationLink(destination: VideoPlayerView(videoURL: video.video_url)) {
                    VStack(alignment: .leading) {
                        Text(video.title).font(.headline)
                        Text(video.description).font(.subheadline).foregroundColor(.gray)
                    }
                }
            }
            .navigationTitle("Doctor Videos")
        }
    }
}
