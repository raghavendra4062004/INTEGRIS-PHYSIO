//
//  ClinicModes6.swift
//  physiotherapy
//
//  Created by SAIL on 09/07/25.
//


import SwiftUI
import MapKit

struct ClinicModes6: Identifiable {
    let id = UUID()
    let name: String
    let city: String
    let distance: String
    let price: String
    let logoName: String
    let latitude: Double
    let longitude: Double
    let address: String
    let description: String
}

let Clinic6 = ClinicModes6(
    name: "Physio Medical",
    city: "Chennai",
    distance: "15 km",
    price: "Rs 250.000 - 400.000",
    logoName: "physio6",
    latitude: 13.02,
    longitude: 80.23,
    address: "321 Health Avenue, Velachery, Chennai - 600042",
    description:
    """
    Physio Medical is dedicated to providing comprehensive rehabilitation services tailored to individual patient needs.

    Their areas of expertise include sports injury recovery, orthopedic physiotherapy, neurological rehabilitation, and pain management.

    The clinic combines modern physiotherapy equipment with skilled manual therapy techniques to ensure optimal recovery and improved well-being.
    """
)

struct ClinicDetailView6: View {
    let clinic: ClinicModes6
    @State private var region: MKCoordinateRegion

    init(clinic: ClinicModes6) {
        self.clinic = clinic
        _region = State(initialValue: MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: clinic.latitude, longitude: clinic.longitude),
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        ))
    }

    var body: some View {
        VStack(spacing: 20) {
            HStack {
                
                Spacer()
                Text("Detail")
                    .font(.title2)
                    .bold()
                Spacer()
                Spacer().frame(width: 44)
            }

            Image("physio6")
                .resizable()
                .scaledToFit()
                .frame(width: 110, height: 110)
                .padding(.top, -10)

            Text(clinic.name.uppercased())
                .font(.title)
                .fontWeight(.bold)

            Button(action: {
                openInMaps(latitude: clinic.latitude, longitude: clinic.longitude)
            }) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(clinic.distance)
                            .font(.headline)
                            .foregroundColor(.blue)

                        Text(clinic.address)
                            .font(.subheadline)
                            .foregroundColor(.black)
                            .lineLimit(nil)
                    }
                    Spacer()
                    Image(systemName: "mappin.and.ellipse")
                        .foregroundColor(.blue)
                }
                .padding()
                .background(Color.purple.opacity(0.2))
                .cornerRadius(20)
                .padding(.horizontal)
            }
            .buttonStyle(PlainButtonStyle())

            ScrollView {
                Text(clinic.description)
                    .font(.body)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
                    .multilineTextAlignment(.leading)
            }

            Spacer()

            Button(action: {
                openInMaps(latitude: clinic.latitude, longitude: clinic.longitude)
            }) {
                Text("Reserve Slot")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(20)
            }
            .padding(.horizontal)
            .padding(.bottom, 30)
        }
        .background(Color(red: 0.93, green: 0.90, blue: 0.98))
        .edgesIgnoringSafeArea(.bottom)
    }

    func openInMaps(latitude: Double, longitude: Double) {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let placemark = MKPlacemark(coordinate: coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = clinic.name
        mapItem.openInMaps(launchOptions: nil)
    }
}

struct ClinicDetailView6_Previews: PreviewProvider {
    static var previews: some View {
        ClinicDetailView6(clinic: Clinic6)
    }
}
