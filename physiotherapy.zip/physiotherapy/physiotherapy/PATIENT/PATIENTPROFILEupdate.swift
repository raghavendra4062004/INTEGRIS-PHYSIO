import SwiftUI

struct PatientInfoView: View {
    @State private var name = "Raghavendra K"
    @State private var age = "22"
    @State private var dob = "14/06/2003"
    @State private var gender = "Male"
    @State private var phone = "123456789"
    @State private var address = "123 Gandhi Street, Chennai, Tamil Nadu"

    @State private var navigateToUpdate = false
    @State private var navigateToLogin = false

    var body: some View {
        NavigationStack {
            ZStack(alignment: .topLeading) {

                LinearGradient(
                    gradient: Gradient(colors: [Color.darkLavender, Color.blue.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    Image("PATIENTPROFILE")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white, lineWidth: 2))
                        .shadow(radius: 5)
                    
                    Text("PATIENT'S INFORMATION")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                    
                    ScrollView {
                        VStack(spacing: 16) {
                            InfoField(label: "Patient Name", text: $name)
                            InfoField(label: "Age", text: $age)
                            InfoField(label: "Date of birth", text: $dob)
                            InfoField(label: "Gender", text: $gender)
                            InfoField(label: "Phone Number", text: $phone)
                            TextAreaField(label: "Address", text: $address)
                        }
                        .padding(.horizontal)
                    }
                    .frame(height: 450)  // ✅ Fixed height for scroll area
                    
                    VStack(spacing: 16) {
                        NavigationLink(destination: AddPatientDetailsView(), isActive: $navigateToUpdate) {
                            Button(action: {
                                navigateToUpdate = true
                            }) {
                                Text("UPDATE")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.purple)
                                    .cornerRadius(16)
                            }
                        }
                        
                        NavigationLink(destination: PATIENTLOGIN(), isActive: $navigateToLogin) {
                            Button(action: {
                                navigateToLogin = true
                            }) {
                                Text("LOG OUT")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.purple)
                                    .cornerRadius(16)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .padding()
            }
            .navigationBarBackButtonHidden(true)
        }
    }

    struct InfoField: View {
        var label: String
        @Binding var text: String

        var body: some View {
            VStack(alignment: .leading, spacing: 4) {
                Text(label)
                    .font(.subheadline)
                    .foregroundColor(.black)

                TextField("Enter \(label.lowercased())", text: $text)
                    .font(.body)
                    .foregroundColor(.black)
                    .padding(.vertical, 5)
                    .overlay(
                        Rectangle()
                            .frame(height: 1)
                            .foregroundColor(.black),
                        alignment: .bottom
                    )
            }
        }
    }

    struct TextAreaField: View {
        var label: String
        @Binding var text: String

        var body: some View {
            VStack(alignment: .leading, spacing: 8) {
                Text(label)
                    .font(.subheadline)
                    .foregroundColor(.black)

                TextEditor(text: $text)
                    .frame(height: 100)
                    .padding(10)
                    .background(Color.white.opacity(0.4))
                    .cornerRadius(14)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color.black.opacity(0.3), lineWidth: 1)
                    )
            }
        }
    }
}


// MARK: - Preview
#Preview {
    PatientInfoView()
}
