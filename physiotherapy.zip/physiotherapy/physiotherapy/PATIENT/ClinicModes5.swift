//
//  ClinicModes5.swift
//  physiotherapy
//
//  Created by SAIL on 09/07/25.
//


import SwiftUI
import MapKit

struct ClinicModes5: Identifiable {
    let id = UUID()
    let name: String
    let city: String
    let distance: String
    let price: String
    let logoName: String
    let latitude: Double
    let longitude: Double
    let address: String
    let description: String
}

let Clinic5 = ClinicModes5(
    name: "Saveetha Physiotherapy Care",
    city: "Chennai",
    distance: "13 km",
    price: "Rs 300.000 - 500.000",
    logoName: "physio5",
    latitude: 13.03,
    longitude: 80.24,
    address: "789, Main Road, Porur, Chennai - 600116",
    description:
    """
    Saveetha Physiotherapy Care is known for its compassionate and evidence-based treatment strategies.

    They specialize in neurological rehabilitation, post-operative care, pain management, and pediatric physiotherapy.

    With a team of highly qualified physiotherapists, they focus on helping patients regain mobility and improve their quality of life through individualized treatment plans.
    """
)

struct ClinicDetailView5: View {
    let clinic: ClinicModes5
    @State private var region: MKCoordinateRegion

    init(clinic: ClinicModes5) {
        self.clinic = clinic
        _region = State(initialValue: MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: clinic.latitude, longitude: clinic.longitude),
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        ))
    }

    var body: some View {
        VStack(spacing: 20) {
            HStack {
                 
                Spacer()
                Text("Detail")
                    .font(.title2)
                    .bold()
                Spacer()
                Spacer().frame(width: 44)
            }

            Image("CLINIC5")
                .resizable()
                .scaledToFit()
                .frame(width: 110, height: 110)
                .padding(.top, -10)

            Text(clinic.name.uppercased())
                .font(.title)
                .fontWeight(.bold)

            Button(action: {
                openInMaps(latitude: clinic.latitude, longitude: clinic.longitude)
            }) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(clinic.distance)
                            .font(.headline)
                            .foregroundColor(.blue)

                        Text(clinic.address)
                            .font(.subheadline)
                            .foregroundColor(.black)
                            .lineLimit(nil)
                    }
                    Spacer()
                    Image(systemName: "mappin.and.ellipse")
                        .foregroundColor(.blue)
                }
                .padding()
                .background(Color.purple.opacity(0.2))
                .cornerRadius(20)
                .padding(.horizontal)
            }
            .buttonStyle(PlainButtonStyle())

            ScrollView {
                Text(clinic.description)
                    .font(.body)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
                    .multilineTextAlignment(.leading)
            }

            Spacer()

            Button(action: {
                openInMaps(latitude: clinic.latitude, longitude: clinic.longitude)
            }) {
                Text("Reserve Slot")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(20)
            }
            .padding(.horizontal)
            .padding(.bottom, 30)
        }
        .background(Color(red: 0.93, green: 0.90, blue: 0.98))
        .edgesIgnoringSafeArea(.bottom)
    }

    func openInMaps(latitude: Double, longitude: Double) {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let placemark = MKPlacemark(coordinate: coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = clinic.name
        mapItem.openInMaps(launchOptions: nil)
    }
}

struct ClinicDetailView5_Previews: PreviewProvider {
    static var previews: some View {
        ClinicDetailView5(clinic: Clinic5)
    }
}
