//
//  ClinicModes4.swift
//  physiotherapy
//
//  Created by SAIL on 09/07/25.
//


import SwiftUI
import MapKit

struct ClinicModes4: Identifiable {
    let id = UUID()
    let name: String
    let city: String
    let distance: String
    let price: String
    let logoName: String
    let latitude: Double
    let longitude: Double
    let address: String
    let description: String
}

let Clinic4 = ClinicModes4(
    name: "Sri Physio Integris",
    city: "Chennai",
    distance: "10 km",
    price: "Rs 350.000 - 500.000",
    logoName: "physio4",
    latitude: 13.04,
    longitude: 80.25,
    address: "456, South Street, Velachery, Chennai - 600042",
    description:
    """
    Sri Physio Integris is dedicated to comprehensive physiotherapy services with a focus on holistic recovery.

    The clinic provides advanced treatments for joint pain, post-surgical rehab, sports injuries, and chronic conditions.

    Their personalized approach ensures that each patient receives the best care in a comfortable and supportive environment.
    """
)

struct ClinicDetailView4: View {
    let clinic: ClinicModes4
    @State private var region: MKCoordinateRegion

    init(clinic: ClinicModes4) {
        self.clinic = clinic
        _region = State(initialValue: MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: clinic.latitude, longitude: clinic.longitude),
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        ))
    }

    var body: some View {
        VStack(spacing: 20) {
            HStack {
                
                Spacer()
                Text("Detail")
                    .font(.title2)
                    .bold()
                Spacer()
                Spacer().frame(width: 44)
            }

            Image("CLINIC4")
                .resizable()
                .scaledToFit()
                .frame(width: 110, height: 110)
                .padding(.top, -10)

            Text(clinic.name.uppercased())
                .font(.title)
                .fontWeight(.bold)

            Button(action: {
                openInMaps(latitude: clinic.latitude, longitude: clinic.longitude)
            }) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(clinic.distance)
                            .font(.headline)
                            .foregroundColor(.blue)

                        Text(clinic.address)
                            .font(.subheadline)
                            .foregroundColor(.black)
                            .lineLimit(nil)
                    }
                    Spacer()
                    Image(systemName: "mappin.and.ellipse")
                        .foregroundColor(.blue)
                }
                .padding()
                .background(Color.purple.opacity(0.2))
                .cornerRadius(20)
                .padding(.horizontal)
            }
            .buttonStyle(PlainButtonStyle())

            ScrollView {
                Text(clinic.description)
                    .font(.body)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
                    .multilineTextAlignment(.leading)
            }

            Spacer()

            Button(action: {
                openInMaps(latitude: clinic.latitude, longitude: clinic.longitude)
            }) {
                Text("Reserve Slot")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(20)
            }
            .padding(.horizontal)
            .padding(.bottom, 30)
        }
        .background(Color(red: 0.93, green: 0.90, blue: 0.98))
        .edgesIgnoringSafeArea(.bottom)
    }

    func openInMaps(latitude: Double, longitude: Double) {
        let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let placemark = MKPlacemark(coordinate: coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = clinic.name
        mapItem.openInMaps(launchOptions: nil)
    }
}

struct ClinicDetailView4_Previews: PreviewProvider {
    static var previews: some View {
        ClinicDetailView4(clinic: Clinic4)
    }
}
