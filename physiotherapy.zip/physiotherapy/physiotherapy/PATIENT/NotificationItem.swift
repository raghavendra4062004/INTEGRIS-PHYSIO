import SwiftUI

// MARK: - Approved Appointment Model
struct ApprovedAppointment: Identifiable, Codable {
    let id = UUID()
    let name: String
    let age: String
    let complaint: String
    let selectedDate: String
    let selectedDoctor: String

    enum CodingKeys: String, CodingKey {
        case name, age, complaint, selectedDate, selectedDoctor
    }
}

// MARK: - API Response Model
struct ApprovedAppointmentResponse: Codable {
    let status: String
    let data: [ApprovedAppointment]
}

// MARK: - Patient Notification View
struct PatientNotificationView: View {
    @State private var notifications: [ApprovedAppointment] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.blue.opacity(0.3)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                if isLoading {
                    ProgressView("Loading...")
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                } else if let error = errorMessage {
                    Text(error)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .padding()
                } else {
                    ScrollView {
                        VStack(spacing: 20) {
                            Text("Doctor Approved Appointments")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.top)

                            ForEach(notifications) { item in
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack {
                                        Image(systemName: "checkmark.seal.fill")
                                            .foregroundColor(.green)
                                        Text("Approved Appointment")
                                            .font(.headline)
                                            .foregroundColor(.black)
                                        Spacer()
                                    }

                                    Divider()

                                    VStack(alignment: .leading, spacing: 5) {
                                        Text("👤 Name: \(item.name)")
                                        Text("🎂 Age: \(item.age)")
                                        Text("🩺 Complaint: \(item.complaint)")
                                        Text("📅 Date: \(item.selectedDate)")
                                        Text("👨‍⚕️ Doctor: \(item.selectedDoctor)")
                                    }
                                    .font(.subheadline)
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(15)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(Color.green, lineWidth: 1)
                                )
                                .shadow(color: .black.opacity(0.1), radius: 4, x: 2, y: 2)
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Notifications")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear(perform: fetchApprovedAppointments)
        }
    }

    // MARK: - Fetch Data
    func fetchApprovedAppointments() {
        guard let url = URL(string: "http://localhost/physiotherapy/notification.php") else {
            errorMessage = "Invalid URL"
            isLoading = false
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                isLoading = false

                if let error = error {
                    errorMessage = "Network error: \(error.localizedDescription)"
                    return
                }

                guard let data = data else {
                    errorMessage = "No data received."
                    return
                }

                do {
                    let decoded = try JSONDecoder().decode(ApprovedAppointmentResponse.self, from: data)
                    if decoded.status == "success" {
                        self.notifications = decoded.data
                    } else {
                        self.errorMessage = "No approved appointments found."
                    }
                } catch {
                    self.errorMessage = "Decoding error: \(error.localizedDescription)"
                }
            }
        }.resume()
    }
}
