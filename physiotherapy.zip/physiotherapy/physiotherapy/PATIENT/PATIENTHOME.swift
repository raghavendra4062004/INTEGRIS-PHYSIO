import SwiftUI
import AVKit

// MARK: - Recommendation Model
struct Recommendation: Identifiable {
    let id = UUID()
    let imageName: String
    let duration: String
    let title: String
    let category: String
    let users: String
    let videoURL: String
}

// MARK: - Article Model
struct ArticleModel1: Identifiable, Codable {
    let id: String
    let doctor_name: String
    let speciality: String
    let title: String
    let content: String
    let created_at: String
    let image_path: String
    var fullImageURL: URL? {
           return URL(string: "http://http://14.139.187.229:8081/mca/integris/\(image_path)")
       }
}

// MARK: - Main Tab View
struct PATIENTHOME: View {
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView().tabItem {
                Image(systemName: "house.fill")
                Text("Home")
            }.tag(0)

            ConsultationView().tabItem {
                Image(systemName: "stethoscope")
                Text("Consultation")
            }.tag(2)

            ClinicListView().tabItem {
                Image(systemName: "cross.case.fill")
                Text("Clinic")
            }.tag(3)

            AppointmentFormView().tabItem {
                Image(systemName: "bubble.left.and.bubble.right.fill")
                Text("Forum")
            }.tag(1)

            PatientInfoView().tabItem {
                Image(systemName: "person.crop.circle.fill")
                Text("Profile")
            }.tag(4)
        }
        .toolbarBackground(Color.purple, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        .accentColor(.purple)
    }
}

// MARK: - Home View
struct HomeView: View {
    let recommendations: [Recommendation] = [
        Recommendation(imageName: "EXERCISE", duration: "15 Minutes", title: "Back Stretch", category: "Stretching", users: "500", videoURL: "https://www.w3schools.com/html/mov_bbb.mp4"),
        Recommendation(imageName: "EXERCISE1", duration: "10 Minutes", title: "Neck Relaxation", category: "Mobility", users: "320", videoURL: "https://www.w3schools.com/html/movie.mp4"),
        Recommendation(imageName: "EXERCISE2", duration: "20 Minutes", title: "Leg Workout", category: "Strength", users: "710", videoURL: "https://www.w3schools.com/html/mov_bbb.mp4"),
        Recommendation(imageName: "EXERCISE3", duration: "12 Minutes", title: "Shoulder Loosening", category: "Mobility", users: "410", videoURL: "https://www.w3schools.com/html/movie.mp4"),
        Recommendation(imageName: "EXERCISE4", duration: "8 Minutes", title: "Wrist Flexibility", category: "Stretching", users: "215", videoURL: "https://www.w3schools.com/html/mov_bbb.mp4")
    ]

    @State private var articles: [ArticleModel1] = []
    @State private var isLoading = true
    @State private var showError = false

    var body: some View {
        NavigationView {
            ZStack(alignment: .topLeading) {
                LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.6), Color.blue.opacity(0.6)]),
                               startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()

                VStack(alignment: .leading) {
                    HeaderView()
                    SearchBar()

                    SectionTitle(title: "Recommendation")
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            ForEach(recommendations) { item in
                                NavigationLink(destination: RecommendationVideoView(recommendation: item)) {
                                    RecommendationCard(recommendation: item)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    .padding(.vertical)

                    SectionTitle(title: "Article")
                    if isLoading {
                        ProgressView("Loading articles...").padding()
                    } else if showError {
                        Text("Failed to load articles").foregroundColor(.red).padding()
                    } else {
                        ScrollView {
                            ForEach(articles) { art in
                                ArticleCard1(article: art).padding(.horizontal)
                            }
                        }
                    }
                }
            }
            .navigationBarTitle("", displayMode: .large)
            .onAppear { fetchArticles() }
        }
    }

    // MARK: - Fetch Articles with POST Form Data
    func fetchArticles() {
        guard let url = URL(string: "http://localhost/physiotherapy/articles.php") else {
            self.showError = true; self.isLoading = false; return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let bodyString = "fetch=true"
        request.httpBody = bodyString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, _, error in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data {
                    do {
                        let decoded = try JSONDecoder().decode([String: [ArticleModel1]].self, from: data)
                        self.articles = decoded["articles"] ?? []
                    } catch {
                        self.showError = true
                    }
                } else {
                    self.showError = true
                }
            }
        }.resume()
    }
}

// MARK: - Recommendation Card
struct RecommendationCard: View {
    var recommendation: Recommendation
    var body: some View {
        HStack(spacing: 10) {
            Image(recommendation.imageName)
                .resizable().scaledToFill()
                .frame(width: 140, height: 140)
                .clipped().cornerRadius(8)

            VStack(alignment: .leading, spacing: 6) {
                Text(recommendation.title).font(.headline).foregroundColor(.white).lineLimit(1)
                Text(recommendation.category).font(.subheadline).foregroundColor(.white.opacity(0.8))
                Spacer()
                HStack {
                    Text(recommendation.duration).font(.caption).foregroundColor(.white)
                    Spacer()
                    Text("\(recommendation.users) users").font(.caption2).foregroundColor(.white.opacity(0.8))
                }
            }
            .padding(.vertical,10).padding(.trailing,10)
        }
        .frame(width: 300, height: 150)
        .background(Color.purple.opacity(0.8)).cornerRadius(12).shadow(color: .black.opacity(0.2), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Video Player View
struct RecommendationVideoView: View {
    var recommendation: Recommendation
    var body: some View {
        VStack(spacing:20) {
            Text(recommendation.title).font(.title).fontWeight(.bold).padding()
            VideoPlayer(player: AVPlayer(url: URL(string: recommendation.videoURL)!))
                .frame(height:250).cornerRadius(15).padding()
            Text("Category: \(recommendation.category)").font(.headline)
            Text("Duration: \(recommendation.duration)").font(.subheadline)
            Text("Users: \(recommendation.users)").font(.subheadline).padding(.bottom)
            Spacer()
        }
        .padding().navigationTitle("Exercise Video").navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Article
struct ArticleCard1: View {
let article: ArticleModel1

var body: some View {
    NavigationLink(destination: DoctorView4(article: article)) {
        HStack {
            VStack(alignment: .leading) {
                Text(article.title)
                    .font(.title3)
                    .fontWeight(.semibold)
                Text("Dr. \(article.doctor_name)")
                    .font(.caption)
                Text(article.speciality)
                    .font(.caption2)
                    .foregroundColor(.gray)
            }

            Spacer()

            AsyncImage(url: article.fullImageURL) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                case .success(let image):
                    image.resizable()
                case .failure:
                    Image(systemName: "photo")
                        .resizable()
                        .foregroundColor(.gray)
                @unknown default:
                    EmptyView()
                }
            }
            .frame(width: 60, height: 60)
            .clipShape(Circle())
        }
        .padding()
        .background(Color.purple.opacity(0.3))
        .cornerRadius(16)
        .padding(.top, 8)
    }
}
}

// MARK: - Article Detail View
struct DoctorView4: View {
    let article: ArticleModel1

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                AsyncImage(url: article.fullImageURL) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                    case .failure:
                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(.gray)
                            .padding()
                    @unknown default:
                        EmptyView()
                    }
                }
                .frame(height: 250)
                .clipped()
                .cornerRadius(12)
                .padding(.horizontal)

                Text(article.title)
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.horizontal)

                Text("By Dr. \(article.doctor_name) • \(article.speciality)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding(.horizontal)

                Text(article.content)
                    .font(.body)
                    .padding(.horizontal)

                Text("Published on \(article.created_at)")
                    .font(.caption)
                    .foregroundColor(.gray)
                    .padding([.horizontal, .bottom])
            }
        }
        .navigationTitle("Article Details")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Header, SearchBar, SectionTitle
struct HeaderView: View {
    @State private var showNotifications = false
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text("👋 Hello!").font(.subheadline).fontWeight(.medium)
                Text("Likith").font(.title).fontWeight(.bold)
            }
            Spacer()
            NavigationLink(destination: PatientNotificationView(), isActive: $showNotifications) { EmptyView() }.hidden()
            Button { showNotifications = true } label: {
                Image(systemName: "bell.fill").font(.title2).foregroundColor(.purple)
            }.padding(.trailing,8)
            Image("PROFILEHOME").resizable().frame(width:50,height:60).clipShape(Circle())
        }.padding()
    }
}

struct SearchBar: View {
    var body: some View {
        RoundedRectangle(cornerRadius:20).fill(Color(.systemGray5)).frame(height:50)
            .overlay(HStack {
                Image(systemName:"magnifyingglass").foregroundColor(.gray)
                Text("Search").foregroundColor(.gray)
                Spacer()
            }.padding(.horizontal)).padding(.horizontal)
    }
}

struct SectionTitle: View {
    var title: String
    var body: some View {
        Text(title).font(.headline).fontWeight(.bold).padding(.leading).padding(.top,20)
    }
}

// MARK: - Preview
#Preview {
    PATIENTHOME()
}
