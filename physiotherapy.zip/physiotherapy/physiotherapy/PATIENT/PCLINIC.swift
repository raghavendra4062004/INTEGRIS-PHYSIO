import SwiftUI
import MapKit

// MARK: - Clinic Model
struct Clinic: Identifiable {
    let id = UUID()
    let name: String
    let city: String
    let distance: String
    let price: String
    let logoName: String
    let latitude: Double
    let longitude: Double
}

// MARK: - Main Tab View
struct ClinicView: View {
    @State private var selectedTab = 3

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }.tag(0)

            ConsultationView()
                .tabItem {
                    Image(systemName: "stethoscope")
                    Text("Consultation")
                }.tag(2)

            ClinicListView()
                .tabItem {
                    Image(systemName: "cross.case.fill")
                    Text("Clinic")
                }.tag(3)

            AppointmentFormView()
                .tabItem {
                    Image(systemName: "bubble.left.and.bubble.right.fill")
                    Text("Forum")
                }.tag(1)

            PatientInfoView()
                .tabItem {
                    Image(systemName: "person.crop.circle.fill")
                    Text("Profile")
                }.tag(4)
        }
        .toolbarBackground(Color.white, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        .accentColor(.purple)
    }
}

// MARK: - Clinic List View
struct ClinicListView: View {
    let clinics = [
        Clinic(name: "PhysioActive", city: "Chennai", distance: "2 km", price: "Rs 150.000 - 300.000", logoName: "physio1", latitude: 13.0827, longitude: 80.2707),
        Clinic(name: "Care and Cure Clinic", city: "Chennai", distance: "3.5 km", price: "Rs 180.000 - 350.000", logoName: "physio2", latitude: 13.075, longitude: 80.280),
        Clinic(name: "Physique Centre", city: "Chennai", distance: "5 km", price: "Rs 200.000 - 400.000", logoName: "physio3", latitude: 13.06, longitude: 80.29),
        Clinic(name: "Sri Physio Integris", city: "Chennai", distance: "10 km", price: "Rs 350.000 - 500.000", logoName: "physio4", latitude: 13.04, longitude: 80.25),
        Clinic(name: "Saveetha Physiotherapy Care", city: "Chennai", distance: "13 km", price: "Rs 300.000 - 500.000", logoName: "physio5", latitude: 13.03, longitude: 80.24),
        Clinic(name: "Physio Medical", city: "Chennai", distance: "15 km", price: "Rs 250.000 - 400.000", logoName: "physio6", latitude: 13.02, longitude: 80.26)
    ]

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.4)]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()

                VStack(alignment: .leading) {
                    HStack {
                        Spacer()
                        Label("Chennai, Tamil Nadu", systemImage: "mappin.and.ellipse")
                            .font(.headline)
                            .foregroundColor(.black)
                        Spacer()
                    }
                    .padding()

                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(clinics.indices, id: \.self) { index in
                                NavigationLink(destination: clinicDestinationView(index: index)) {
                                    HStack {
                                        Image(systemName: "cross.case.fill")
                                            .resizable()
                                            .frame(width: 50, height: 50)
                                            .foregroundColor(.purple)
                                            .padding(4)
                                            .background(Color.white)
                                            .clipShape(RoundedRectangle(cornerRadius: 10))

                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(clinics[index].name)
                                                .font(.headline)
                                                .foregroundColor(.white)
                                            Text("\(clinics[index].city) • \(clinics[index].distance)")
                                                .font(.subheadline)
                                                .foregroundColor(.white.opacity(0.9))
                                            Text("Price: \(clinics[index].price)")
                                                .font(.subheadline)
                                                .foregroundColor(.white.opacity(0.7))
                                        }

                                        Spacer()
                                        Image(systemName: "chevron.right")
                                            .foregroundColor(.white)
                                    }
                                    .padding()
                                    .background(Color.white.opacity(0.3))
                                    .cornerRadius(16)
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
           // .navigationBarTitle("Clinics", displayMode: .inline)
            .navigationBarBackButtonHidden(true)
        }
    }

    @ViewBuilder
    func clinicDestinationView(index: Int) -> some View {
        switch index {
        case 0: ClinicDetailView1(clinic: Clinic1)    // Replace this with your actual screen
        case 1:  ClinicDetailView2(clinic: Clinic2)    // Replace this with your actual screen
        case 2:  ClinicDetailView3(clinic: Clinic3)    // Replace this with your actual screen
        case 3:  ClinicDetailView4(clinic: Clinic4)   // Replace this with your actual screen
        case 4: ClinicDetailView5(clinic: Clinic5)    // Replace this with your actual screen
        case 5: ClinicDetailView6(clinic: Clinic6)    // Replace this with your actual screen
        default: Text("Clinic Not Found")
        }
    }
}

//// MARK: - Placeholder Views (You can delete these if you already have real ones)
//struct HomeView: View { var body: some View { Text("Home View") } }
//struct ConsultationView: View { var body: some View { Text("Consultation View") } }
//struct AppointmentFormView: View { var body: some View { Text("Forum View") } }
//struct PatientInfoView: View { var body: some View { Text("Profile View") } }

// Replace these with your real clinic detail screens
struct Clinic1View: View { var body: some View { Text("Clinic 1 Detail Screen") } }
struct Clinic2View: View { var body: some View { Text("Clinic 2 Detail Screen") } }
struct Clinic3View: View { var body: some View { Text("Clinic 3 Detail Screen") } }
struct Clinic4View: View { var body: some View { Text("Clinic 4 Detail Screen") } }
struct Clinic5View: View { var body: some View { Text("Clinic 5 Detail Screen") } }
struct Clinic6View: View { var body: some View { Text("Clinic 6 Detail Screen") } }

// MARK: - Preview
#Preview {
    ClinicView()
}
