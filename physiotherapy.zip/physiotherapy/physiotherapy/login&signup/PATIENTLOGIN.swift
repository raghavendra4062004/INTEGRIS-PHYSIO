import SwiftUI

struct PATIENTLOGIN: View {
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var navigateToHome = false
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        NavigationStack {
            ZStack(alignment: .topLeading) {

                LinearGradient(
                    gradient: Gradient(colors: [Color.darkLavender, Color.blue.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 18) {
                    Spacer().frame(height: 30)

                    Text("PATIENT\nLOGIN")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.purple)
                        .multilineTextAlignment(.center)
                        .padding(.top, -20)

                    Spacer()

                    Image("patient")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 220)

                    Spacer()

                    TextField("User Name", text: $username)
                        .padding()
                        .frame(height: 60)
                        .background(Color.white.opacity(0.3))
                        .cornerRadius(15)
                        .padding(.horizontal)

                    SecureField("Password", text: $password)
                        .padding()
                        .frame(height: 60)
                        .background(Color.white.opacity(0.3))
                        .cornerRadius(15)
                        .padding(.horizontal)

                    NavigationLink(destination: AddPatientDetailsView(), isActive: $navigateToHome) {
                        EmptyView()
                    }

                    Button(action: {
                        loginUser()
                    }) {
                        Text("Login")
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple)
                            .cornerRadius(20)
                            .shadow(radius: 5)
                    }
                    .padding(.horizontal)

                    NavigationLink(destination: SignUpView()) {
                        HStack {
                            Text("Don't have an account? ")
                                .foregroundColor(.black)
                            Text("Sign Up")
                                .foregroundColor(.purple)
                                .fontWeight(.semibold)
                        }
                        .font(.system(size: 16))
                    }
                    .padding(.top, 5)

                    Spacer()
                }
                .padding(.top)
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Login Status"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                }
            }
            .navigationBarHidden(true) 
        }
    }

    // MARK: - API Call
    func loginUser() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/integris/patient_login.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let postString = "username=\(username)&password=\(password)"
        request.httpBody = postString.data(using: .utf8)

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                DispatchQueue.main.async {
                    self.alertMessage = "Network error. Please try again."
                    self.showAlert = true
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: String],
                   let status = json["status"],
                   let message = json["message"] {

                    DispatchQueue.main.async {
                        if status == "success" {
                            self.navigateToHome = true
                        } else {
                            self.alertMessage = message
                            self.showAlert = true
                        }
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.alertMessage = "Invalid server response."
                    self.showAlert = true
                }
            }
        }

        task.resume()
    }
}

#Preview {
    PATIENTLOGIN()
}
