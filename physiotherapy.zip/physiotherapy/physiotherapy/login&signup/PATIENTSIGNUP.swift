import SwiftUI

// MARK: - Custom Color Extension
extension Color {
    static let lightPurple = Color(red: 230 / 255, green: 230 / 255, blue: 250 / 255)
}

// MARK: - Sign Up View
struct SignUpView: View {
    @State private var username: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var phoneNumber: String = ""
    @State private var gender: String = "Male"

    let genders = ["Male", "Female", "Other"]

    @State private var navigateToLogin = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var isRegisteredSuccessfully = false

    // ✅ Fix compiler gradient issue
    let backgroundGradient = Gradient(colors: [
        Color.purple.opacity(0.5),
        Color.blue.opacity(0.4)
    ])

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: backgroundGradient,
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    Text("Sign Up")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.purple)

                    Spacer()

                    ScrollView {
                        VStack(alignment: .leading, spacing: 15) {
                            TextField("Username", text: $username)
                                .padding()
                                .background(Color.white.opacity(0.2))
                                .cornerRadius(10)

                            TextField("Email", text: $email)
                                .padding()
                                .keyboardType(.emailAddress)
                                .autocapitalization(.none)
                                .background(Color.white.opacity(0.2))
                                .cornerRadius(10)

                            TextField("Phone Number", text: $phoneNumber)
                                .padding()
                                .keyboardType(.phonePad)
                                .background(Color.white.opacity(0.2))
                                .cornerRadius(10)

                            SecureField("Password", text: $password)
                                .padding()
                                .background(Color.white.opacity(0.2))
                                .cornerRadius(10)

                            SecureField("Confirm Password", text: $confirmPassword)
                                .padding()
                                .background(Color.white.opacity(0.2))
                                .cornerRadius(10)

                            VStack(alignment: .leading, spacing: 5) {
                                Text("Gender")
                                    .fontWeight(.semibold)
                                    .foregroundColor(.purple)

                                Picker("Gender", selection: $gender) {
                                    ForEach(genders, id: \.self) { genderOption in
                                        Text(genderOption)
                                            .foregroundColor(.black)
                                            .tag(genderOption)
                                    }
                                }
                                .pickerStyle(SegmentedPickerStyle())
                                .background(Color.lightPurple)
                                .cornerRadius(8)
                                .padding(.horizontal)
                                .tint(.white)
                            }
                            .padding(.top, 5)
                        }
                        .padding(.horizontal, 30)
                    }

                    NavigationLink(destination: PATIENTLOGIN(), isActive: $navigateToLogin) {
                        EmptyView()
                    }

                    Button(action: {
                        registerUser()
                    }) {
                        Text("Sign Up")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal, 30)
                    .padding(.top, 10)

                    Spacer()
                    Spacer()
                    Spacer()
                }
                .padding(.top, 30)
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Registration Status"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("OK"), action: {
                        if isRegisteredSuccessfully {
                            navigateToLogin = true
                        }
                    })
                )
            }
            .navigationBarHidden(true)
        }
    }

    // MARK: - API Call
    func registerUser() {
        guard !username.isEmpty, !email.isEmpty, !phoneNumber.isEmpty, !password.isEmpty, !confirmPassword.isEmpty else {
            alertMessage = "All fields are required."
            showAlert = true
            return
        }

        guard password == confirmPassword else {
            alertMessage = "Passwords do not match."
            showAlert = true
            return
        }

        guard let url = URL(string: "http://14.139.187.229:8081/mca/integris/patientusers.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "username=\(username)&email=\(email)&phone=\(phoneNumber)&password=\(password)&gender=\(gender)"
        request.httpBody = postString.data(using: .utf8)

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                DispatchQueue.main.async {
                    self.alertMessage = "Network error. Please try again."
                    self.showAlert = true
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: String],
                   let status = json["status"],
                   let message = json["message"] {

                    DispatchQueue.main.async {
                        self.alertMessage = message
                        self.isRegisteredSuccessfully = (status == "success")
                        self.showAlert = true
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.alertMessage = "Invalid server response."
                    self.showAlert = true
                }
            }
        }

        task.resume()
    }
}

// MARK: - Preview
struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}
