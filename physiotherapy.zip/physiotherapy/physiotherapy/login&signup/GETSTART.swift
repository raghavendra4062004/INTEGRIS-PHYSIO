import SwiftUI

struct GETSTART: View {
    var body: some View {
        NavigationStack {
            ZStack {
                // Gradient Background
                LinearGradient(
                    gradient: Gradient(colors: [Color.darkLavender, Color.blue.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    Spacer().frame(height: 40)

                    Spacer()

                    VStack(spacing: 8) {
                        Text("WELCOME !")
                            .font(.system(size: 36, weight: .heavy))
                            .foregroundColor(Color.purple)
                            .shadow(color: Color.purple.opacity(0.3), radius: 6)

                        Text("INTEGRIS")
                            .font(.system(size: 40, weight: .bold))
                            .foregroundColor(Color.purple)

                        Text("PHYSIO CARE AND REHAB CENTRE")
                            .font(.system(size: 16))
                            .foregroundColor(Color.purple)
                            .multilineTextAlignment(.center)
                    }

                    Image("123456")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 260, height: 260)

                    Spacer()

                    NavigationLink(destination: WELCOME()) {
                        Text("Get Started")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple)
                            .cornerRadius(16)
                            .padding(.horizontal, 32)
                    }

                    Spacer().frame(height: 30)
                }
            }
        }
    }
}

#Preview {
    GETSTART()
}
