import SwiftUI

struct DOCTORLOGIN: View {
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var navigateToDashboard = false
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        NavigationStack {
            ZStack(alignment: .topLeading) {

                LinearGradient(
                    gradient: Gradient(colors: [Color.darkLavender, Color.blue.opacity(0.4)]),
                    startPoint: .bottom,
                    endPoint: .top
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    Spacer().frame(height: 30)

                    Text("DOCTOR\nLOGIN")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.purple)
                        .multilineTextAlignment(.center)
                        .padding(.top, -20)

                    Spacer()

                    Image("doctor")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 220)

                    Spacer()

                    TextField("User Name", text: $username)
                        .padding()
                        .frame(height: 60)
                        .background(Color.lightLavender.opacity(0.3))
                        .cornerRadius(15)
                        .padding(.horizontal)

                    SecureField("Password", text: $password)
                        .padding()
                        .frame(height: 60)
                        .background(Color.lightLavender.opacity(0.23))
                        .cornerRadius(15)
                        .padding(.horizontal)

                    NavigationLink(destination: DoctorEditProfileScreen(), isActive: $navigateToDashboard) {
                        EmptyView()
                    }

                    Button(action: {
                        doctorLogin()
                    }) {
                        Text("Login")
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple)
                            .cornerRadius(20)
                            .shadow(radius: 5)
                    }
                    .padding(.horizontal)

                    NavigationLink(destination: DoctorSignUpView()) {
                        HStack {
                            Text("Don't have an account? ")
                                .foregroundColor(.black)
                            Text("Sign Up")
                                .foregroundColor(.purple)
                                .fontWeight(.semibold)
                        }
                        .font(.system(size: 16))
                        .padding(.top, 10)
                    }

                    Spacer()
                }
                .padding(.top)
            }
            .navigationBarHidden(true)
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Login Failed"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    func doctorLogin() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/integris/doctor_login.php") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let postString = "username=\(username)&password=\(password)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }

            guard let data = data else { return }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if let status = json["status"] as? String, let message = json["message"] as? String {
                        DispatchQueue.main.async {
                            if status == "success" {
                                navigateToDashboard = true
                            } else {
                                alertMessage = message
                                showAlert = true
                            }
                        }
                    }
                }
            } catch {
                print("JSON parsing error: \(error.localizedDescription)")
            }
        }.resume()
    }
}

#Preview {
    DOCTORLOGIN()
}
