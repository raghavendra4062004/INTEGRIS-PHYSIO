import SwiftUI

struct WELCOME: View {
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        NavigationView {
            ZStack(alignment: .topLeading) {
                LinearGradient(
                    gradient: Gradient(colors: [Color.darkLavender, Color.blue.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Spacer().frame(height: 90)
                    
                    Image("login")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 200, height: 300)
                    
                    NavigationLink(destination: PATIENTLOGIN()) {
                        CustomLoginButton(label: "Patient")
                    }
                    
                    NavigationLink(destination: DOCTORLOGIN()) {
                        CustomLoginButton(label: "Doctor")
                    }
                }
                .padding(.top, 20)
                .padding(.leading, 10)
            }
            //.navigationBarHidden(true)
        }
    }
}

// Custom Button View
struct CustomLoginButton: View {
    let label: String

    var body: some View {
        Text(label)
            .font(.system(size: 20, weight: .semibold))
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color(red: 141/255, green: 84/255, blue: 142/255))
            .foregroundColor(.white)
            .cornerRadius(12)
            .padding(.horizontal, 20)
            .shadow(radius: 4)
    }
}


#Preview {
    WELCOME()
}
