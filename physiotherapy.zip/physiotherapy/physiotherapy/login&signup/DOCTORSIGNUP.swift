import SwiftUI

struct DoctorSignUpView: View {
    @State private var username = ""
    @State private var email = ""
    @State private var phoneNumber = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var gender = "Male"

    @State private var navigateToLogin = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var isRegisteredSuccessfully = false

    let genders = ["Male", "Female", "Other"]

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.5), Color.blue.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()


                VStack(spacing: 20) {
                    Text("Doctor Sign Up")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top)

                    ScrollView {
                        VStack(spacing: 15) {
                            inputField("Username", text: $username)
                            inputField("Email", text: $email, keyboard: .emailAddress)
                            inputField("Phone Number", text: $phoneNumber, keyboard: .phonePad)
                            secureField("Password", text: $password)
                            secureField("Confirm Password", text: $confirmPassword)

                            VStack(alignment: .leading) {
                                Text("Gender")
                                    .fontWeight(.semibold)
                                    .foregroundColor(.white)
                                Picker("Gender", selection: $gender) {
                                    ForEach(genders, id: \.self) {
                                        Text($0)
                                    }
                                }
                                .pickerStyle(SegmentedPickerStyle())
                                .tint(.white)
                            }
                            .padding(.top, 10)
                        }
                        .padding(.horizontal)
                    }

                    Button(action: registerDoctor) {
                        Text("Sign Up")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)

                    NavigationLink(destination: DOCTORLOGIN(), isActive: $navigateToLogin) {
                        EmptyView()
                    }
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Registration Status"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("OK")) {
                        if isRegisteredSuccessfully {
                            navigateToLogin = true
                        }
                    }
                )
            }
            .navigationBarHidden(true)
        }
    }

    // MARK: - Input Helpers
    func inputField(_ placeholder: String, text: Binding<String>, keyboard: UIKeyboardType = .default) -> some View {
        TextField(placeholder, text: text)
            .padding()
            .keyboardType(keyboard)
            .autocapitalization(.none)
            .background(Color.white.opacity(0.2))
            .cornerRadius(10)
            .foregroundColor(.white)
    }

    func secureField(_ placeholder: String, text: Binding<String>) -> some View {
        SecureField(placeholder, text: text)
            .padding()
            .background(Color.white.opacity(0.2))
            .cornerRadius(10)
            .foregroundColor(.white)
    }

    // MARK: - Registration Function
    func registerDoctor() {
        guard !username.isEmpty, !email.isEmpty, !phoneNumber.isEmpty, !password.isEmpty, !confirmPassword.isEmpty else {
            alertMessage = "All fields are required."
            showAlert = true
            return
        }

        guard password == confirmPassword else {
            alertMessage = "Passwords do not match."
            showAlert = true
            return
        }

        guard let url = URL(string: "http://14.139.187.229:8081/mca/integris/doctorusers.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "username=\(username)&email=\(email)&phone=\(phoneNumber)&password=\(password)&gender=\(gender)"
        request.httpBody = postString.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                DispatchQueue.main.async {
                    alertMessage = "Network error. Please try again."
                    showAlert = true
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: String],
                   let status = json["status"],
                   let message = json["message"] {
                    DispatchQueue.main.async {
                        alertMessage = message
                        isRegisteredSuccessfully = (status == "success")
                        showAlert = true
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    alertMessage = "Invalid server response."
                    showAlert = true
                }
            }
        }.resume()
    }
}

// MARK: - Preview
#Preview {
    DoctorSignUpView()
}
