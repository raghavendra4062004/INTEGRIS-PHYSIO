import SwiftUI

@main
struct Physiotheraphy: App {
    var body: some Scene {
        WindowGroup {
            GETSTART()
        }
    }
}
