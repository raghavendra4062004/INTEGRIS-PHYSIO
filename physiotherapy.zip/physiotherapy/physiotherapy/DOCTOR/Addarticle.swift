import SwiftUI

struct AddArticleView: View {
    var doctorName: String
    var speciality: String

    @State private var articleTitle: String = ""
    @State private var articleContent: String = ""
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        NavigationView {
            ZStack(alignment: .topLeading) {
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.4)]),
                    startPoint: .bottom,
                    endPoint: .top
                )
                .ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {

                        // Doctor Profile Section
                        HStack(alignment: .center, spacing: 16) {
                            Image("consult_janu")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 80, height: 80)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.blue, lineWidth: 2))
                                .shadow(radius: 4)

                            VStack(alignment: .leading) {
                                Text(doctorName)
                                    .font(.title3)
                                    .fontWeight(.bold)

                                Text(speciality)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                        }

                        Divider()

                        // Title Input
                        TextField("Enter article title", text: $articleTitle)
                            .textFieldStyle(RoundedBorderTextFieldStyle())

                        // Content Input
                        Text("Article Content:")
                            .font(.headline)

                        TextEditor(text: $articleContent)
                            .frame(height: 200)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray.opacity(0.9), lineWidth: 1)
                            )

                        // Save Button
                        Button(action: {
                            submitArticle()
                        }) {
                            Text("Save Article")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    }
                    .padding()
                }
                .navigationTitle("Article")
                .alert(isPresented: $showAlert) {
                    Alert(
                        title: Text("Status"),
                        message: Text(alertMessage),
                        dismissButton: .default(Text("OK"))
                    )
                }
            }
        }
    }

    func submitArticle() {
        guard let url = URL(string: "http://14.139.187.229:8081/mca/integris/addarticle.php") else {
            alertMessage = "Invalid URL."
            showAlert = true
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let params = [
            "doctorName": doctorName,
            "speciality": speciality,
            "articleTitle": articleTitle,
            "articleContent": articleContent
        ]

        let bodyString = params.map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")" }
            .joined(separator: "&")

        request.httpBody = bodyString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    alertMessage = "Request failed: \(error.localizedDescription)"
                    showAlert = true
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    alertMessage = "No response from server."
                    showAlert = true
                }
                return
            }

            do {
                let result = try JSONDecoder().decode(ServerResponse.self, from: data)
                DispatchQueue.main.async {
                    alertMessage = result.message
                    showAlert = true
                }
            } catch {
                DispatchQueue.main.async {
                    alertMessage = "Unexpected server response."
                    showAlert = true
                }
            }
        }.resume()
    }
}

struct ServerResponse: Codable {
    let status: String
    let message: String
}

#Preview {
    AddArticleView(doctorName: "Dr. Janani", speciality: "Therapist")
}
