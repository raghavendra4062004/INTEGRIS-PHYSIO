import SwiftUI

// MARK: - Patient Model
struct Patient: Identifiable {
    let id = UUID()
    let name: String
}

// MARK: - Main View
struct PatientListView: View {
    @State private var patients: [Patient] = []
    @State private var newPatientName: String = ""

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 20) {
                Text("List of Patients")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top)
                    .padding(.horizontal)

                // TextField + Button to Add Patients
                HStack {
                    TextField("Enter patient name", text: $newPatientName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading)

                    Button(action: {
                        let trimmedName = newPatientName.trimmingCharacters(in: .whitespaces)
                        if !trimmedName.isEmpty {
                            patients.append(Patient(name: trimmedName))
                            newPatientName = ""
                        }
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundColor(.blue)
                    }
                    .padding(.trailing)
                }

                ScrollView {
                    VStack(spacing: 12) {
                        ForEach(patients) { patient in
                            NavigationLink(destination: PatientDetailView(patient: patient)) {
                                PatientCardView(name: patient.name)
                            }
                        }
                    }
                    .padding(.bottom)
                }
            }
            .padding(.bottom)
            .background(Color.lightLavender.ignoresSafeArea())
            .navigationBarHidden(true)
        }
    }
}

// MARK: - Reusable Card View
struct PatientCardView: View {
    let name: String

    var body: some View {
        Text(name)
            .font(.title3)
            .fontWeight(.semibold)
            .foregroundColor(.white)
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.darkLavender)
            .cornerRadius(12)
            .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 3)
            .padding(.horizontal)
    }
}

// MARK: - Patient Detail View
struct PatientDetailView: View {
    let patient: Patient

    var body: some View {
        VStack(spacing: 20) {
            Text("Patient Details")
                .font(.largeTitle)
                .fontWeight(.bold)

            Text("Name: \(patient.name)")
                .font(.title2)

            Spacer()
        }
        .padding()
        .navigationTitle("Details")
    }
}

extension Color {
    static let lightLavender = Color(hex: "#F5EAFE")   // Very light lavender
    static let darkLavender = Color(hex: "#D1A3FF")    // Dark lavender
}

// MARK: - Preview
#Preview {
    PatientListView()
}
