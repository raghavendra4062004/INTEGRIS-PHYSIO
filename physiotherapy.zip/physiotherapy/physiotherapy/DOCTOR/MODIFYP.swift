import SwiftUI

struct PatientSearchView: View {
    @State private var searchText: String = ""

    var body: some View {
        VStack {
            
     Text("Patient Search")
            Spacer()
            
            // Search TextField
            TextField("Search by Patient ID or Name", text: $searchText)
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).stroke(Color.purple, lineWidth: 1))
                .padding(.horizontal, 40)
            
            // Enter Button
            Button(action: {
                // Handle enter action
            }) {
                Text("Enter")
                    .foregroundColor(.white)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 40)
                    .background(Color.gray)
                    .cornerRadius(10)
            }
            .padding(.top, 20)
            
            Spacer()
        }
        .background(Color(red: 0.9, green: 0.9, blue: 0.98).ignoresSafeArea()) // Light lavender
    }
}

#Preview {
    PatientSearchView()
}
