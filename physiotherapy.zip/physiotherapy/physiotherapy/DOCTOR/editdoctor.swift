import SwiftUI
import PhotosUI

struct DoctorEditProfileScreen: View {
    @State private var doctorID = ""
    @State private var doctorNote = ""
    @State private var name = ""
    @State private var speciality = ""
    @State private var gender = "Male"
    @State private var contact = ""
    @State private var navigateToDashboard = false

    @State private var selectedImage: PhotosPickerItem?
    @State private var profileImage: Image? = nil

    let genders = ["Male", "Female", "Other"]

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.blue.opacity(0.5)]),
                    startPoint: .topLeading,
                    endPoint: .topTrailing
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    Text("Your Profile")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding(.top, 20)

                    Spacer()

                    // Profile Image Picker
                    PhotosPicker(selection: $selectedImage, matching: .images) {
                        if let profileImage = profileImage {
                            profileImage
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .overlay(
                                    Circle()
                                        .stroke(Color.darkLavender, lineWidth: 4)
                                )
                                .shadow(radius: 10)
                        } else {
                            Image(systemName: "person.crop.circle.fill")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 120, height: 120)
                                .clipShape(Circle())
                                .overlay(
                                    Circle()
                                        .stroke(Color.purple, lineWidth: 4)
                                )
                                .shadow(radius: 10)
                        }
                    }
                    .onChange(of: selectedImage) { newItem in
                        if let newItem = newItem {
                            loadImage(from: newItem)
                        }
                    }

                    VStack(spacing: 16) {
                        DoctorProfileField(icon: "person.badge.plus", text: $doctorID, placeholder: "Doctor ID (Username)")
                        DoctorProfileField(icon: "person.fill", text: $name, placeholder: "Enter your name")
                        DoctorProfileField(icon: "phone.fill", text: $contact, placeholder: "Phone number")

                        // Gender Picker
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Gender")
                                .fontWeight(.semibold)
                                .foregroundColor(.purple)

                            Picker("Gender", selection: $gender) {
                                ForEach(genders, id: \.self) { genderOption in
                                    Text(genderOption)
                                        .foregroundColor(.black)
                                        .tag(genderOption)
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                        }

                        DoctorProfileField(icon: "cross.fill", text: $speciality, placeholder: "Your speciality")
                        DoctorProfileField(icon: "text.book.closed.fill", text: $doctorNote, placeholder: "Doctor’s Note")

                        Button(action: {
                            saveDoctorProfile()
                        }) {
                            Text("Save")
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.purple)
                                .cornerRadius(10)
                        }

                        Button("Cancel") {
                            navigateToDashboard = false
                        }
                        .foregroundColor(.black)
                    }
                    .padding()
                    .background(Color.lightLavender.opacity(0.5))
                    .cornerRadius(18)
                    .shadow(radius: 5)
                    .padding(.horizontal)

                    Spacer()

                    NavigationLink(destination: DashboardView(doctorID: doctorID,
                                                              name: name,
                                                              speciality: speciality), isActive: $navigateToDashboard) {
                        EmptyView()
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }

    // MARK: - API Integration
    func saveDoctorProfile() {
        guard let url = URL(string: "http://localhost/physiotherapy/doctorprofile.php") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let parameters: [String: String] = [
            "username": doctorID,
            "name": name,
            "contact": contact,
            "gender": gender,
            "speciality": speciality,
            "doctorNote": doctorNote
        ]

        let bodyString = parameters.map { "\($0.key)=\($0.value)" }.joined(separator: "&")
        request.httpBody = bodyString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }

            guard let data = data else { return }

            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                    DispatchQueue.main.async {
                        if let status = json["status"] as? String, status == "success" {
                            print("Profile saved successfully")
                            navigateToDashboard = true
                        } else {
                            print(json["message"] as? String ?? "Unknown error")
                        }
                    }
                }
            } catch {
                print("JSON Parsing Error: \(error.localizedDescription)")
            }
        }.resume()
    }

    // Load Image Function
    func loadImage(from item: PhotosPickerItem) {
        item.loadTransferable(type: Data.self) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    if let data = data, let uiImage = UIImage(data: data) {
                        self.profileImage = Image(uiImage: uiImage)
                    }
                case .failure(let error):
                    print("Error loading image: \(error.localizedDescription)")
                }
            }
        }
    }
}

struct DoctorProfileField: View {
    let icon: String
    @Binding var text: String
    var placeholder: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(.gray)

            ZStack(alignment: .leading) {
                if text.isEmpty {
                    Text(placeholder)
                        .foregroundColor(Color.gray.opacity(0.6))
                }
                TextField("", text: $text)
                    .foregroundColor(.black)
            }
        }
        .padding()
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.gray.opacity(0.6), lineWidth: 1)
        )
    }
}
#Preview {
    DoctorEditProfileScreen()
}
