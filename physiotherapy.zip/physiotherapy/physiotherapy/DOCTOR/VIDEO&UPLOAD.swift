import SwiftUI
import PhotosUI
import AVKit

struct DoctorUploadVideoScreen: View {
    @State private var videoTitle: String = ""
    @State private var videoDescription: String = ""
    @State private var selectedVideo: PhotosPickerItem?
    @State private var videoURL: URL?

    @State private var uploadedVideos: [DoctorVideo] = []

    var body: some View {
        NavigationView {
            ZStack(alignment: .topLeading) {
                // Gradient Background
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.5)]),
                    startPoint: .topLeading,
                    endPoint: .topTrailing
                )
                .ignoresSafeArea()

                VStack(alignment: .leading, spacing: 20) {
                    // Upload Form - Sticky
                    Text("Upload Exercise Video")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding(.top, 20)

                    TextField("Enter video title", text: $videoTitle)
                        .padding()
                        .background(Color.darkLavender.opacity(0.2))
                        .cornerRadius(8)

                    TextField("Enter video description", text: $videoDescription, axis: .vertical)
                        .padding()
                        .background(Color.darkLavender.opacity(0.2))
                        .cornerRadius(8)
                        .lineLimit(4)

                    PhotosPicker(selection: $selectedVideo, matching: .videos, photoLibrary: .shared()) {
                        HStack {
                            Image(systemName: "video.fill.badge.plus")
                            Text(selectedVideo == nil ? "Select Video" : "Video Selected")
                        }
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .onChange(of: selectedVideo) { newItem in
                        if let item = newItem {
                            item.loadTransferable(type: URL.self) { result in
                                switch result {
                                case .success(let url):
                                    if let url = url {
                                        self.videoURL = url
                                        print("Selected video URL: \(url)")
                                    }
                                case .failure(let error):
                                    print("Error loading video: \(error.localizedDescription)")
                                }
                            }
                        }
                    }

                    Button(action: {
                        uploadVideo()
                    }) {
                        Text("Upload Video")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.purple)
                            .cornerRadius(10)
                    }

                    Divider()
                        .padding(.vertical, 10)

                    Text("Uploaded Videos")
                        .font(.headline)
                        .foregroundColor(.darkLavender)

                    // Scrollable Uploaded Videos Only
                    ScrollView {
                        VStack(alignment: .leading, spacing: 16) {
                            ForEach(uploadedVideos.reversed(), id: \.id) { video in
                                VStack(alignment: .leading, spacing: 8) {
                                    Text(video.title)
                                        .font(.headline)
                                        .foregroundColor(.white)

                                    Text(video.description)
                                        .font(.subheadline)
                                        .foregroundColor(.white.opacity(0.8))

                                    // Black Thumbnail with Play Overlay
                                    ZStack {
                                        Rectangle()
                                            .fill(Color.black)
                                            .frame(height: 200)
                                            .cornerRadius(8)

                                        VideoPlayer(player: AVPlayer(url: video.url))
                                            .frame(height: 200)
                                            .cornerRadius(8)
                                            .opacity(0.0) // Hide video by default

                                        Image(systemName: "play.circle.fill")
                                            .resizable()
                                            .frame(width: 50, height: 50)
                                            .foregroundColor(.white)
                                    }
                                }
                            }
                        }
                        .padding(.bottom, 20)
                    }

                    Spacer()
                }
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    func uploadVideo() {
        guard !videoTitle.isEmpty, !videoDescription.isEmpty, let videoURL = videoURL else {
            print("Please fill all fields and select a video.")
            return
        }

        let newVideo = DoctorVideo(id: UUID(), title: videoTitle, description: videoDescription, url: videoURL)
        uploadedVideos.append(newVideo)

        videoTitle = ""
        videoDescription = ""
        selectedVideo = nil
        self.videoURL = nil

        print("Video uploaded successfully!")
    }
}

struct DoctorVideo {
    let id: UUID
    let title: String
    let description: String
    let url: URL
}

#Preview {
    DoctorUploadVideoScreen()
}
