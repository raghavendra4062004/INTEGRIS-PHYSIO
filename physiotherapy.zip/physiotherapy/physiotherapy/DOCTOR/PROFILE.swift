import SwiftUI

struct DoctorProfileView: View {
    let doctorID: String

    @State private var name: String = ""
    @State private var gender: String = ""
    @State private var contact: String = ""
    @State private var speciality: String = ""
    @State private var doctorNote: String = ""
    @State private var isLoading = true

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.6)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                if isLoading {
                    ProgressView("Loading profile...")
                        .foregroundColor(.white)
                } else {
                    VStack(spacing: 30) {
                        Text("Your Profile")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.darkLavender)
                            .padding(.top, 40)

                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                            .overlay(
                                Circle().stroke(Color.darkLavender, lineWidth: 4)
                            )
                            .shadow(radius: 10)

                        VStack(alignment: .leading, spacing: 15) {
                            Text("Doctor ID: \(doctorID)")
                            Text("Name: \(name)")
                            Text("Gender: \(gender)")
                            Text("Contact: \(contact)")
                            Text("Speciality: \(speciality)")
                            Text("Note: \(doctorNote)")

                            Divider().padding(.vertical, 5)

                            NavigationLink(destination: DoctorEditProfileScreen()) {
                                Text("Edit Profile")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.purple)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                            }
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.lightLavender)
                                .shadow(color: Color.darkLavender.opacity(0.12), radius: 10, x: 0, y: 6)
                        )
                        .padding(.horizontal, 24)

                        Spacer()
                    }
                }
            }
            .onAppear {
                fetchDoctorProfile()
            }
            .navigationBarHidden(true)
        }
    }

    func fetchDoctorProfile() {
        guard let url = URL(string: "http://http://14.139.187.229:8081/mca/integris/get_doctor_profile.php") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let bodyString = "doctorID=\(doctorID)"
        request.httpBody = bodyString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Network Error: \(error.localizedDescription)")
                return
            }

            guard let data = data else { return }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if let status = json["status"] as? String, status == "success",
                       let doctorData = json["data"] as? [String: Any] {

                        DispatchQueue.main.async {
                            self.name = doctorData["name"] as? String ?? ""
                            self.gender = doctorData["gender"] as? String ?? ""
                            self.contact = doctorData["contact"] as? String ?? ""
                            self.speciality = doctorData["speciality"] as? String ?? ""
                            self.doctorNote = doctorData["doctorNote"] as? String ?? ""
                            self.isLoading = false
                        }
                    } else {
                        print(json["message"] as? String ?? "Unknown error")
                    }
                }
            } catch {
                print("JSON parsing error: \(error.localizedDescription)")
            }
        }.resume()
    }
}

#Preview {
    DoctorProfileView(doctorID: "Doc0002")
}
