import SwiftUI

struct DoctorArticleCard: View {
    var doctor: String
    var specialty: String
    var title: String

    @Environment(\.dismiss) var dismiss
    var body: some View {
        VStack(spacing: 90) {
            Spacer()
            // Title
            Text(title)
                .font(.title3)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            Divider()

            // Info Boxes
            HStack(spacing: 90) {
                InfoBox1(title: "Doctor", value: doctor)
                InfoBox1(title: "Specialty", value: specialty)
            }
            .padding()

            // About Section
            VStack(alignment: .leading, spacing: 10) {
                Text("About")
                    .font(.headline)

                Text("""
                This therapy is a part of advanced musculoskeletal rehabilitation. It focuses on mobilization and myofascial release techniques to relieve stiffness and improve functional movement.

                Tailored especially for post-injury and post-surgical recovery, this therapy helps enhance muscle activation and reduce inflammation through manual therapy and customized routines.
                """)
                    .foregroundColor(.gray)
            }
            .padding()

            Spacer()

            // Start Button
            Button(action: {
                print("Start button tapped")
            }) {
                Text("Start Therapy")
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .foregroundColor(.white)
                    .cornerRadius(15)
                    .shadow(radius: 5)
            }
            .padding(.horizontal)
            .padding(.bottom, 30)
        }
        .edgesIgnoringSafeArea(.top)
        .navigationBarHidden(true)
        .toolbar(.hidden, for: .tabBar)
    }
}

// Reusable Info Box
struct InfoBox1: View {
    var title: String
    var value: String

    var body: some View {
        VStack {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.gray)

            Text(value)
                .font(.headline)
                .multilineTextAlignment(.center)
        }
        .frame(width: 120, height: 70)
        .background(Color(UIColor.systemGray6))
        .cornerRadius(15)
        .shadow(radius: 5)
    }
}

#Preview {
    DoctorArticleCard(
        doctor: "Dr.Sathish .K",
        specialty: "Orthopedic Rehabilitation",
        title: "Post-Injury Muscle Activation & Recovery Therapy"
    )
}





