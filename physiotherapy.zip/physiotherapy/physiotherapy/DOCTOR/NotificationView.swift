import SwiftUI

// MARK: - Appointment Model
struct AppointmentNotification: Identifiable, Codable {
    let id = UUID()
    let name: String
    let age: String
    let complaint: String
    let selectedDate: String
    let selectedDoctor: String

    enum CodingKeys: String, CodingKey {
        case name, age, complaint, selectedDate, selectedDoctor
    }
}

// MARK: - API Response Model
struct AppointmentResponse: Codable {
    let status: String
    let data: [AppointmentNotification]
}

// MARK: - Notification View
struct NotificationView: View {
    @State private var notifications: [AppointmentNotification] = []
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var approvedAppointments: Set<UUID> = []

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.darkLavender, Color.blue.opacity(0.4)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                if isLoading {
                    ProgressView("Loading...")
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                } else if let error = errorMessage {
                    Text(error)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .padding()
                } else {
                    ScrollView {
                        VStack(spacing: 20) {
                            Text("Appointment Notifications")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.top)

                            ForEach(notifications) { notification in
                                VStack(alignment: .leading, spacing: 10) {
                                    HStack {
                                        Image(systemName: "bell.fill")
                                            .foregroundColor(.purple)
                                        Text("New Appointment")
                                            .font(.headline)
                                            .foregroundColor(.black)

                                        Spacer()

                                        // ✅ Small Approve Button on Right Side
                                        Button(action: {
                                            approveAppointment(notification)
                                        }) {
                                            Text(approvedAppointments.contains(notification.id) ? "✓" : "Approve")
                                                .font(.caption)
                                                .foregroundColor(.white)
                                                .padding(.horizontal, 10)
                                                .padding(.vertical, 5)
                                                .background(approvedAppointments.contains(notification.id) ? Color.green : Color.blue)
                                                .cornerRadius(8)
                                        }
                                        .disabled(approvedAppointments.contains(notification.id))
                                    }

                                    Divider()

                                    VStack(alignment: .leading, spacing: 6) {
                                        HStack {
                                            Text(" Name:")
                                                .fontWeight(.semibold)
                                            Text(notification.name)
                                        }
                                        HStack {
                                            Text(" Age:")
                                                .fontWeight(.semibold)
                                            Text(notification.age)
                                        }
                                        HStack {
                                            Text(" Complaint:")
                                                .fontWeight(.semibold)
                                            Text(notification.complaint)
                                        }
                                        HStack {
                                            Text(" Date:")
                                                .fontWeight(.semibold)
                                            Text(notification.selectedDate)
                                        }
                                        HStack {
                                            Text("🩺 Doctor:")
                                                .fontWeight(.semibold)
                                            Text(notification.selectedDoctor)
                                        }
                                    }
                                }
                                .padding()
                                .background(Color.white)
                                .cornerRadius(15)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(Color.purple, lineWidth: 1)
                                )
                                .shadow(color: Color.black.opacity(0.1), radius: 4, x: 2, y: 2)
                            }

                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Notifications")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear(perform: fetchAppointments)
        }
    }

    // MARK: - Fetch Appointments
    func fetchAppointments() {
        guard let url = URL(string: "http://http://14.139.187.229:8081/mca/integris/notification.php") else {
            errorMessage = "Invalid URL"
            isLoading = false
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                isLoading = false

                if let error = error {
                    errorMessage = "Network Error: \(error.localizedDescription)"
                    return
                }

                guard let data = data else {
                    errorMessage = "No data received"
                    return
                }

                do {
                    let decoded = try JSONDecoder().decode(AppointmentResponse.self, from: data)
                    if decoded.status == "success" {
                        self.notifications = decoded.data
                    } else {
                        self.errorMessage = "No appointments found."
                    }
                } catch {
                    self.errorMessage = "Decoding Error: \(error.localizedDescription)"
                }
            }
        }.resume()
    }

    // MARK: - Approve Button Action
    func approveAppointment(_ notification: AppointmentNotification) {
        // Optional: Send approval to server here
        approvedAppointments.insert(notification.id)
        print("Approved appointment for \(notification.name)")
    }
}

// MARK: - Preview
#Preview {
    NotificationView()
}
