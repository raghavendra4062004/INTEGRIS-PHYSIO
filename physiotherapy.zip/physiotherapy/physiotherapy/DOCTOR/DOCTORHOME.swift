import SwiftUI

// MARK: - Dashboard View
struct DashboardView: View {
    // Passed values from previous screen
    let doctorID: String
    let name: String
    let speciality: String

    // Navigation States
    @State private var isNavigatingToDoctorProfile = false
    @State private var isNavigatingToAddPatient = false
    @State private var isNavigatingToUploadVideo = false
    @State private var isNavigatingToListPatient = false
    @State private var isNavigatingToNotification = false  // ✅ Added for Notification Navigation

    // Article Data
    @State private var selectedDoctor: String = ""
    @State private var selectedSpecialty: String = ""
    @State private var selectedVideoURL: String = ""
    @State private var selectedTitle: String = ""

    var body: some View {
        NavigationView {
            GeometryReader { geo in
                VStack(spacing: 20) {
                    // Doctor Profile Header
                    HStack(spacing: 10) {
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .frame(width: 70, height: 70)
                            .foregroundColor(.white)

                        VStack(alignment: .leading, spacing: 4) {
                            Text("Dr. \(name)")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text(speciality)
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.8))
                        }

                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.top, geo.safeAreaInsets.top + 10)

                    // Dashboard Image
                    Image("dashboard_image")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: geo.size.width * 0.9, maxHeight: 220)
                        .padding(.horizontal)

                    // Dashboard Buttons
                    VStack(spacing: 16) {
                        DashboardButton(icon: "person.badge.plus", label: "Doctor Profile") {
                            isNavigatingToDoctorProfile = true
                        }

                        DashboardButton(icon: "bell.fill", label: "Notification from Patient") {
                            isNavigatingToNotification = true  // ✅ Navigate to Notification
                        }

                        DashboardButton(icon: "list.bullet", label: "List of Patient") {
                            isNavigatingToListPatient = true
                        }

                        DashboardButton(icon: "plus.circle", label: "Add New Patient Details") {
                            selectedDoctor = "Dr. \(name)"
                            selectedSpecialty = speciality
                            selectedVideoURL = "https://www.w3schools.com/html/mov_bbb.mp4"
                            selectedTitle = "Legs and Lower Legs Stretching Movements"
                            isNavigatingToAddPatient = true
                        }

                        DashboardButton(icon: "pencil.and.outline", label: "View/Modify Patient Details") {
                            // Add action here when ready
                        }

                        DashboardButton(icon: "video.fill", label: "Upload Video") {
                            isNavigatingToUploadVideo = true
                        }
                    }

                    Spacer()
                    Spacer()

                    // Navigation Links
                    NavigationLink(destination: DoctorProfileView(doctorID: doctorID), isActive: $isNavigatingToDoctorProfile) {
                        EmptyView()
                    }

                    NavigationLink(
                        destination: DoctorArticleCard(
                            doctor: selectedDoctor,
                            specialty: selectedSpecialty,
                            title: selectedTitle
                        ),
                        isActive: $isNavigatingToAddPatient
                    ) {
                        EmptyView()
                    }

                    NavigationLink(destination: DoctorUploadVideoScreen(), isActive: $isNavigatingToUploadVideo) {
                        EmptyView()
                    }

                    NavigationLink(destination: PatientListView(), isActive: $isNavigatingToListPatient) {
                        EmptyView()
                    }

                    NavigationLink(destination: NotificationView(), isActive: $isNavigatingToNotification) {
                        EmptyView()
                    }
                }
                .frame(width: geo.size.width, height: geo.size.height)
                .padding(.bottom)
            }
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple.opacity(0.7), Color.blue.opacity(0.6)]),
                    startPoint: .topLeading,
                    endPoint: .topTrailing
                )
                .ignoresSafeArea()
            )
        }
    }
}

// MARK: - Dashboard Button
struct DashboardButton: View {
    let icon: String
    let label: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                Text(label)
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.purple.opacity(0.5))
            .foregroundColor(.purple)
            .cornerRadius(10)
            .padding(.horizontal)
        }
    }
}
// MARK: - Preview
#Preview {
    DashboardView(doctorID: "D1234", name: "Likith", speciality: "Orthopedic")
}

