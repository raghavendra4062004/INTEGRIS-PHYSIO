
import SwiftUI

// MARK: - Doctor Model
struct Consult1: Identifiable {
    let id = UUID()
    let name: String
    let experience: String
    let price: String
    let rating: Double
    let imageName: String
}

// MARK: - Doctor Detail View
struct DoctorDetailView1: View {
    let doctor: Consult1
    @State private var showVideo = false
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Image(doctor.imageName)
                    .resizable()
                    .frame(width: 150, height: 150)
                    .clipShape(Circle())
                    .shadow(radius: 10)
                    .padding(.top, 20)

                Text("dr.JANANI")
                    .font(.title2)
                    .bold()

                Text("Specialization: Physiotherapist")
                    .font(.subheadline)

                Text("Experience: \(doctor.experience)")
                    .font(.subheadline)

                Text("Consultation Fee: \(doctor.price)")
                    .font(.subheadline)

                HStack {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                    Text(String(format: "%.1f", doctor.rating))
                }

                Divider().padding(.vertical)

                Button(action: {
                    // Add chat or video consult logic
                }) {
                    Label("Consult Now", systemImage: "message.fill")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .padding(.horizontal)
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("Doctor's Advice")
                        .font(.headline)
                        .padding(.horizontal)

                    Text("""
                    • Stay hydrated
                    • Regular walk 30 mins/day
                    • Avoid junk food
                    • Monitor blood pressure weekly
                    """)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("Exercise Video")
                        .font(.headline)
                        .padding(.horizontal)

                    Image("exercise_thumbnail")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(height: 200)
                        .cornerRadius(15)
                        .padding(.horizontal)

                    Button(action: {
                        showVideo = true
                    }) {
                        Text("Play Exercise Video")
                            .font(.caption)
                            .padding(.vertical, 8)
                            .padding(.horizontal, 16)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                }

                Spacer()
            }
            .padding(.bottom, 40)
        }
        .background(Color(red: 233/255, green: 230/255, blue: 250/255).ignoresSafeArea())
        .navigationTitle("Doctor Details")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action: {
                    dismiss()
                }) {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                }
            }
        }
        .sheet(isPresented: $showVideo) {
            ExerciseVideo()
        }
    }
}

// MARK: - Exercise Video View
struct ExerciseVideo: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Exercise Video")
                .font(.title)
                .bold()
                .padding()

            Image("exercise_thumbnail")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(15)
                .padding()

            Text("This is a demonstration of physiotherapy exercises to improve flexibility and strength.")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding()

            Spacer()
        }
        .padding()
    }
}

// MARK: - Preview
#Preview {
    NavigationStack {
        DoctorDetailView1(doctor: Consult1(
            name: "Dr. Arishiya",
            experience: "3 years",
            price: "Rs 1,000",
            rating: 4.9,
            imageName: "ARISHYA"
        ))
    }
}
